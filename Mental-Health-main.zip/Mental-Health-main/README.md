# MindEase Flutter Project

Converted from the Figma/React design (MindEase_mobile_app_design.zip).

## Project Structure

```
lib/
├── main.dart                          ← App entry point
│
├── core/
│   ├── theme/
│   │   └── app_theme.dart             ← Colors, typography, ThemeData (from theme.css)
│   └── router/
│       └── app_router.dart            ← GoRouter with all 14 routes (from routes.tsx)
│
├── features/
│   ├── shell/
│   │   └── main_shell.dart            ← Bottom nav bar shell (from Layout.tsx)
│   │
│   ├── onboarding/
│   │   └── screens/
│   │       ├── splash_screen.dart     ← (from Splash.tsx)
│   │       ├── onboarding_carousel_screen.dart  ← (from OnboardingCarousel.tsx)
│   │       └── onboarding_consent_screen.dart   ← (from OnboardingConsent.tsx)
│   │
│   ├── auth/
│   │   └── screens/
│   │       └── auth_screen.dart       ← Email + Google + biometric (from Auth.tsx)
│   │
│   ├── assessment/
│   │   └── screens/
│   │       └── assessment_screen.dart ← PHQ-9/GAD-7 (from Assessment.tsx)
│   │
│   ├── home/
│   │   └── screens/
│   │       └── home_screen.dart       ✅ DONE — Mood ring, streak, quick actions
│   │
│   ├── chat/
│   │   └── screens/
│   │       └── chat_screen.dart       ✅ DONE — AI chat bubbles, typing indicator, crisis banner
│   │
│   ├── mood/
│   │   └── screens/
│   │       └── mood_log_screen.dart   ← Emoji picker, intensity slider, tags (from MoodLog.tsx)
│   │
│   ├── exercises/
│   │   └── screens/
│   │       ├── exercises_screen.dart  ← CBT exercise cards (from Exercises.tsx)
│   │       └── exercise_detail_screen.dart ← Step-by-step + breathing animation (from ExerciseDetail.tsx)
│   │
│   ├── journal/
│   │   └── screens/
│   │       └── journal_screen.dart    ← AI journal with sentiment (from Journal.tsx)
│   │
│   ├── progress/
│   │   └── screens/
│   │       └── progress_screen.dart   ← fl_chart mood graph, heatmap (from Progress.tsx)
│   │
│   ├── crisis/
│   │   └── screens/
│   │       └── crisis_screen.dart     ✅ DONE — Helpline, dark gradient, therapist card
│   │
│   └── profile/
│       └── screens/
│           └── profile_screen.dart    ← Settings, wearable toggle (from Profile.tsx)
│
└── shared/
    ├── widgets/
    │   ├── app_button.dart
    │   ├── app_card.dart
    │   └── mood_chip.dart
    └── models/
        ├── user.dart
        ├── mood_entry.dart
        ├── chat_message.dart
        └── exercise.dart
```

## Color Tokens (from theme.css → app_theme.dart)

| Token           | Light              | Dark               |
|-----------------|--------------------|--------------------|
| Primary Blue    | #5B7FFF            | #7B9FFF            |
| Accent Coral    | #FF8C69            | #FFAC89            |
| Background      | #F7F5F2            | #1A1A2E            |
| Surface/Card    | #FFFFFF            | #252538            |
| Success Mint    | #4CAF82            | #6CCF9C            |
| Alert Red       | #FF5252            | #FF7272            |
| Text Primary    | #1A1A2E            | #F7F5F2            |
| Text Secondary  | #6B7280            | #9CA3AF            |

## Typography

| Use            | Font            | Weight |
|----------------|-----------------|--------|
| H1-H3 headings | Fraunces        | 600    |
| Body / UI      | Plus Jakarta Sans| 400/500|

## Key Dependencies

```yaml
go_router: ^13.0.0          # Navigation (replaces react-router)
flutter_riverpod: ^2.4.0    # State management
google_fonts: ^6.1.0        # Fraunces + Plus Jakarta Sans
fl_chart: ^0.67.0           # Mood trend charts (replaces recharts)
flutter_local_notifications  # Smart nudges
```

## Next Steps

1. Run `flutter pub get`
2. Download fonts via google_fonts or add font files to `assets/fonts/`
3. Implement remaining screens following the pattern in home_screen.dart
4. Wire up real AI API in chat_screen.dart (replace mock responses)
5. Add Firebase Auth for the auth_screen.dart

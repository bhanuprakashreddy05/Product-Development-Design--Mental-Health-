import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mental_health/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    // Basic verification that the app widget constructs
    expect(const MindEaseApp(), isA<MindEaseApp>());
  });
}

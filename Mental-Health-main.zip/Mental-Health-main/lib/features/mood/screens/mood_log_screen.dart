import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../core/theme/app_theme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/user_provider.dart';
class _Emotion {
  final String emoji;
  final String label;
  final Color color;
  const _Emotion(this.emoji, this.label, this.color);
}

const _emotions = [
  _Emotion('😊', 'Happy', AppColors.successMint),
  _Emotion('😔', 'Sad', AppColors.primaryBlue),
  _Emotion('😰', 'Anxious', AppColors.accentCoral),
  _Emotion('😡', 'Angry', AppColors.alertRed),
  _Emotion('😴', 'Tired', AppColors.textSecondary),
  _Emotion('😌', 'Calm', AppColors.successMint),
  _Emotion('🤗', 'Hopeful', AppColors.primaryBlue),
];

const _tags = [
  'Anxious', 'Tired', 'Hopeful', 'Overwhelmed', 'Peaceful', 'Stressed',
  'Grateful', 'Lonely', 'Excited', 'Frustrated', 'Content', 'Worried',
];

class MoodLogScreen extends ConsumerStatefulWidget {
  const MoodLogScreen({super.key});

  @override
  ConsumerState<MoodLogScreen> createState() => _MoodLogScreenState();
}

class _MoodLogScreenState extends ConsumerState<MoodLogScreen>
    with SingleTickerProviderStateMixin {
  int? _selectedEmotion;
  double _intensity = 50;
  final Set<String> _selectedTags = {};
  final _noteController = TextEditingController();
  bool _showAffirmation = false;
  late AnimationController _affirmationController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _affirmationController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _scaleAnim = CurvedAnimation(
        parent: _affirmationController, curve: Curves.elasticOut);
  }

  @override
  void dispose() {
    _noteController.dispose();
    _affirmationController.dispose();
    super.dispose();
  }

  void _submit() {
    if (_selectedEmotion == null) return;
    
    final emotion = _emotions[_selectedEmotion!];
    final entry = MoodEntry(
      date: DateTime.now(),
      emoji: emotion.emoji,
      label: emotion.label,
      intensity: _intensity.toInt(),
      tags: _selectedTags.toList(),
      note: _noteController.text,
    );
    
    ref.read(moodLogProvider.notifier).add(entry);
    ref.read(streakProvider.notifier).updateStreak();

    setState(() => _showAffirmation = true);
    _affirmationController.forward();
    Future.delayed(const Duration(milliseconds: 2200), () {
      if (mounted) context.go('/app');
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_showAffirmation) return _buildAffirmation(context);

    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Column(
        children: [
          // Header
          SafeArea(
            bottom: false,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                border: const Border(bottom: BorderSide(color: AppColors.border)),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.go('/app'),
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: theme.scaffoldBackgroundColor,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.chevron_left, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Text('Log Your Mood', style: theme.textTheme.headlineSmall),
                ],
              ),
            ),
          ),

          // Scrollable content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Emoji picker
                  Text('How are you feeling?',
                      style: theme.textTheme.titleMedium),
                  const SizedBox(height: 12),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.85,
                    ),
                    itemCount: _emotions.length,
                    itemBuilder: (ctx, i) {
                      final e = _emotions[i];
                      final selected = _selectedEmotion == i;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedEmotion = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          decoration: BoxDecoration(
                            color: selected
                                ? e.color.withValues(alpha: 0.15)
                                : theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? e.color.withValues(alpha: 0.5)
                                  : AppColors.border,
                              width: selected ? 2 : 1,
                            ),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(e.emoji,
                                  style: const TextStyle(fontSize: 32)),
                              const SizedBox(height: 4),
                              Text(e.label,
                                  style: theme.textTheme.bodySmall?.copyWith(
                                    fontWeight: FontWeight.w500,
                                    color: selected
                                        ? e.color
                                        : AppColors.textSecondary,
                                  )),
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                  // Intensity slider
                  if (_selectedEmotion != null) ...[
                    const SizedBox(height: 28),
                    Text('Intensity', style: theme.textTheme.titleMedium),
                    const SizedBox(height: 8),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: AppColors.primaryBlue,
                        inactiveTrackColor: AppColors.muted,
                        thumbColor: AppColors.primaryBlue,
                        overlayColor:
                            AppColors.primaryBlue.withValues(alpha: 0.15),
                        trackHeight: 4,
                      ),
                      child: Slider(
                        value: _intensity,
                        min: 0,
                        max: 100,
                        onChanged: (v) => setState(() => _intensity = v),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Mild', style: theme.textTheme.bodySmall),
                        Text('${_intensity.toInt()}%',
                            style: theme.textTheme.bodySmall?.copyWith(
                                fontWeight: FontWeight.w600,
                                color: AppColors.primaryBlue)),
                        Text('Intense', style: theme.textTheme.bodySmall),
                      ],
                    ),
                  ],

                  const SizedBox(height: 28),

                  // Tags
                  Text('What else are you feeling?',
                      style: theme.textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: _tags.map((tag) {
                      final selected = _selectedTags.contains(tag);
                      return GestureDetector(
                        onTap: () => setState(() {
                          if (selected) {
                            _selectedTags.remove(tag);
                          } else {
                            _selectedTags.add(tag);
                          }
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: selected
                                ? AppColors.primaryBlue
                                : theme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                              color: selected
                                  ? AppColors.primaryBlue
                                  : AppColors.border,
                            ),
                          ),
                          child: Text(
                            tag,
                            style: TextStyle(
                              fontSize: 13,
                              color: selected
                                  ? Colors.white
                                  : AppColors.textPrimary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 28),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Add a note (optional)',
                          style: theme.textTheme.titleMedium),
                      _VoiceButton(
                        onResult: (text) {
                          setState(() {
                            _noteController.text = text;
                            _noteController.selection = TextSelection.fromPosition(
                              TextPosition(offset: _noteController.text.length),
                            );
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _noteController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: "What's on your mind?",
                      fillColor: theme.colorScheme.surface,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ),

          // Submit button
          Padding(
            padding:
                EdgeInsets.fromLTRB(24, 8, 24, MediaQuery.of(context).padding.bottom + 16),
            child: ElevatedButton(
              onPressed: _selectedEmotion != null ? _submit : null,
              child: const Text('Save Mood Log'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAffirmation(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.successMint.withValues(alpha: 0.2),
              AppColors.successMint.withValues(alpha: 0.05),
            ],
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: _scaleAnim,
                  child: Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      color: AppColors.successMint.withValues(alpha: 0.2),
                      shape: BoxShape.circle,
                     ),
                    child: const Icon(Icons.auto_awesome,
                        color: AppColors.successMint, size: 40),
                  ),
                ),
                const SizedBox(height: 24),
                Text('Thank You for Sharing',
                    style: theme.textTheme.headlineMedium,
                    textAlign: TextAlign.center),
                const SizedBox(height: 12),
                Text(
                  'Tracking your emotions is a powerful step toward understanding yourself better. You\'re doing great! 🌟',
                  style: theme.textTheme.bodyLarge
                      ?.copyWith(color: AppColors.textSecondary, height: 1.6),
                  textAlign: TextAlign.center,
                ),
              ],
             ),
           ),
        ),
      ),
    );
  }
}

class _VoiceButton extends StatefulWidget {
  final Function(String) onResult;
  const _VoiceButton({required this.onResult});

  @override
  State<_VoiceButton> createState() => _VoiceButtonState();
}

class _VoiceButtonState extends State<_VoiceButton> with SingleTickerProviderStateMixin {
  final _stt = SpeechToText();
  bool _isListening = false;
  bool _sttAvailable = false;
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _initStt();
  }

  Future<void> _initStt() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      _sttAvailable = await _stt.initialize(
        onStatus: (s) {
          if (s == 'notListening' || s == 'done') {
            if (mounted) {
              setState(() => _isListening = false);
              _ctrl.stop();
            }
          }
        },
      );
      if (mounted) setState(() {});
    }
  }

  void _toggle() async {
    if (_isListening) {
      await _stt.stop();
      return;
    }
    if (!_sttAvailable) return;
    
    setState(() => _isListening = true);
    _ctrl.repeat(reverse: true);
    await _stt.listen(
      onResult: (res) => widget.onResult(res.recognizedWords),
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
    );
  }

  @override
  void dispose() {
    _stt.stop();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_sttAvailable) return const SizedBox.shrink();
    return GestureDetector(
      onTap: _toggle,
      child: ScaleTransition(
        scale: _isListening ? Tween<double>(begin: 1.0, end: 1.2).animate(_ctrl) : const AlwaysStoppedAnimation(1.0),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _isListening ? AppColors.accentCoral : AppColors.primaryBlue.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(
            _isListening ? Icons.mic : Icons.mic_none,
            color: _isListening ? Colors.white : AppColors.primaryBlue,
            size: 20,
          ),
        ),
      ),
    );
  }
}

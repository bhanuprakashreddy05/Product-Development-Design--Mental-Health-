import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/services/gemini_service.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../core/theme/app_theme.dart';

// ── Model ─────────────────────────────────────────────────────────────────────
class ChatMessage {
  final String id;
  String text;           // mutable — we stream into it
  final bool isUser;
  final bool isError;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    this.isError = false,
    required this.timestamp,
  });
}



// ── Screen ────────────────────────────────────────────────────────────────────
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen>
    with SingleTickerProviderStateMixin {
  // Controllers
  final _inputCtrl  = TextEditingController();
  final _scrollCtrl = ScrollController();

  // State
  bool _isStreaming  = false;
  bool _showCrisis   = false;
  bool _isSpeaking   = false;   // TTS playing
  String? _speakingId;          // which bubble is being read

  // Voice input
  final _stt        = SpeechToText();
  bool _sttAvailable = false;
  bool _isListening  = false;
  String _voiceText  = '';

  // Text to speech
  final _tts = FlutterTts();

  // Pulse animation for mic
  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  // Conversation history for Gemini
  final List<Map<String, dynamic>> _history = [];

  final List<ChatMessage> _messages = [
    ChatMessage(
      id: '0',
      text: "Hi there 💙 I'm Mental Health, your AI companion.\n\n"
            "I use evidence-based CBT techniques to support you. "
            "You can type or tap the 🎤 mic to speak.\n\n"
            "How are you feeling today?",
      isUser: false,
      timestamp: DateTime.now(),
    ),
  ];

  static const _crisisWords = [
    'suicide','kill myself','end it all','hurt myself',
    'self harm','self-harm','not worth living','better off dead',
    'want to die',"can't go on",'cant go on',
  ];

  bool _isCrisis(String t) =>
      _crisisWords.any((w) => t.toLowerCase().contains(w));

  // ── Init ─────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();

    // Pulse animation for mic button
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.18)
        .animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _pulseCtrl.stop();

    _initStt();
    _initTts();
  }

  Future<void> _initStt() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      _sttAvailable = await _stt.initialize(
        onError: (e) => debugPrint('STT error: $e'),
        onStatus: (s) {
          if (s == 'done' || s == 'notListening') {
            setState(() => _isListening = false);
            _pulseCtrl.stop();
            _pulseCtrl.reset();
            if (_voiceText.isNotEmpty) {
              _inputCtrl.text = _voiceText;
              _voiceText = '';
            }
          }
        },
      );
      setState(() {});
    }
  }

  Future<void> _initTts() async {
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.48);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.05);
    _tts.setCompletionHandler(() {
      setState(() { _isSpeaking = false; _speakingId = null; });
    });
  }

  // ── Voice input ───────────────────────────────────────────────────────────
  Future<void> _toggleListening() async {
    if (_isListening) {
      await _stt.stop();
      setState(() => _isListening = false);
      _pulseCtrl.stop();
      _pulseCtrl.reset();
      return;
    }

    if (!_sttAvailable) {
      _showSnack('Microphone not available. Check permissions.', isError: true);
      return;
    }

    setState(() { _isListening = true; _voiceText = ''; _inputCtrl.clear(); });
    _pulseCtrl.repeat(reverse: true);

    await _stt.listen(
      onResult: (result) {
        setState(() {
          _voiceText = result.recognizedWords;
          _inputCtrl.text = _voiceText;
          _inputCtrl.selection = TextSelection.fromPosition(
              TextPosition(offset: _inputCtrl.text.length));
        });
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      localeId: 'en_US',
    );
  }

  // ── Voice output ──────────────────────────────────────────────────────────
  Future<void> _speak(ChatMessage msg) async {
    if (_isSpeaking && _speakingId == msg.id) {
      await _tts.stop();
      setState(() { _isSpeaking = false; _speakingId = null; });
      return;
    }
    await _tts.stop();
    setState(() { _isSpeaking = true; _speakingId = msg.id; });
    // Strip emojis/symbols for cleaner TTS
    final clean = msg.text
        .replaceAll(RegExp(r'[^\x00-\x7F]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    await _tts.speak(clean);
  }

  // ── Gemini streaming call ─────────────────────────────────────────────────
  Future<void> _sendMessage() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty || _isStreaming) return;

    // Stop listening if active
    if (_isListening) { await _stt.stop(); setState(() => _isListening = false); }

    // Add user bubble
    setState(() {
      _messages.add(ChatMessage(
        id: 'u_${DateTime.now().millisecondsSinceEpoch}',
        text: text,
        isUser: true,
        timestamp: DateTime.now(),
      ));
      _isStreaming = true;
      if (_isCrisis(text)) _showCrisis = true;
    });
    _inputCtrl.clear();
    _scrollToBottom();

    // Add empty AI bubble — we'll stream into it
    final aiMsg = ChatMessage(
      id: 'ai_${DateTime.now().millisecondsSinceEpoch}',
      text: '',
      isUser: false,
      timestamp: DateTime.now(),
    );
    setState(() => _messages.add(aiMsg));

    // Add to Gemini history
    _history.add({'role': 'user', 'parts': [{'text': text}]});
    
    // Keep internal history manageable (e.g., last 15 messages)
    if (_history.length > 15) {
      _history.removeRange(0, _history.length - 15);
    }


    const systemPrompt =
        'You are Mental Health, a compassionate AI companion trained in '
        'Cognitive Behavioural Therapy (CBT). '
        'Listen empathetically, validate feelings, and use CBT techniques: '
        'grounding (5-4-3-2-1), thought records, breathing exercises, '
        'cognitive restructuring, and behavioural activation. '
        'Keep replies warm and concise (3-5 sentences). '
        'Always end with one follow-up question or a small actionable step. '
        'If the user expresses suicidal ideation, express care and strongly '
        'encourage a crisis helpline immediately. '
        'Never diagnose or replace a licensed therapist. '
        'Tone: warm, calm, non-judgmental, gently encouraging.';

    try {
      // Stream deltas from the central Gemini client
      await for (final delta in geminiService.streamGenerateContent(
        systemPrompt: systemPrompt,
        contents: _history,
        generationConfig: {
          'temperature': 0.78,
          'maxOutputTokens': 400,
          'topP': 0.9,
        },
      ).timeout(const Duration(seconds: 60))) {
        setState(() {
          aiMsg.text = aiMsg.text + delta;
        });
        _scrollToBottom();
      }

      final completeText = aiMsg.text;
      if (completeText.isNotEmpty) {
        _history.add({'role': 'model', 'parts': [{'text': completeText}]});
      }

      setState(() => _isStreaming = false);

      if (completeText.isNotEmpty) _speak(aiMsg);

    } on TimeoutException {
      setState(() {
        aiMsg.text = "Connection timed out. Please check your internet and try again.";
        _history.removeLast(); // Remove user message from history if it failed
        _isStreaming = false;
      });
    } catch (e) {
      final err = e.toString();
      setState(() {
        aiMsg.text = err.contains('Gemini API key')
            ? '⚠️ Gemini API key not set. Add GEMINI_API_KEY to your .env file.'
            : (err.length > 120 ? '${err.substring(0, 120)}...' : err);
        _history.removeLast();
        _isStreaming = false;
      });
    }
  }


  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? AppColors.alertRed : AppColors.successMint,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ));
  }

  void _resetChat() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Start new session?'),
        content: const Text('Clears conversation and resets AI memory.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _tts.stop();
              setState(() {
                _messages..clear()..add(ChatMessage(
                  id: '0',
                  text: "Fresh start 💙 How are you feeling right now?",
                  isUser: false,
                  timestamp: DateTime.now(),
                ));
                _history.clear();
                _showCrisis   = false;
                _isSpeaking   = false;
                _speakingId   = null;
              });
            },
            child: const Text('Reset',
                style: TextStyle(color: AppColors.alertRed)),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _scrollCtrl.dispose();
    _stt.stop();
    _tts.stop();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        title: Row(children: [
          Container(
            width: 40, height: 40,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                  colors: [AppColors.primaryBlue, AppColors.accentCoral]),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('AI',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Mental Health AI', style: theme.textTheme.titleMedium),
            Row(children: [
              Container(width: 7, height: 7,
                decoration: const BoxDecoration(
                    color: AppColors.successMint, shape: BoxShape.circle)),
              const SizedBox(width: 4),
              Text('Gemini · Voice enabled',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(fontSize: 10, color: AppColors.textSecondary)),
            ]),
          ]),
        ]),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_outlined),
            tooltip: 'New session',
            onPressed: _resetChat,
          ),
        ],
      ),
      body: Column(children: [

        // ── Crisis banner ──────────────────────────────────────────────
        if (_showCrisis)
          Container(
            color: AppColors.alertRed,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(children: [
              const Icon(Icons.warning_amber_rounded,
                  color: Colors.white, size: 20),
              const SizedBox(width: 8),
              const Expanded(
                child: Text("You're not alone. Help is available.",
                    style: TextStyle(color: Colors.white, fontSize: 13)),
              ),
              TextButton(
                onPressed: () => context.go('/crisis'),
                child: const Text('Get Help',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              GestureDetector(
                onTap: () => setState(() => _showCrisis = false),
                child: const Icon(Icons.close, color: Colors.white, size: 18),
              ),
            ]),
          ),

        // ── Voice listening banner ─────────────────────────────────────
        if (_isListening)
          Container(
            color: AppColors.primaryBlue.withOpacity(0.08),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(children: [
              ScaleTransition(
                scale: _pulseAnim,
                child: const Icon(Icons.mic,
                    color: AppColors.primaryBlue, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  _voiceText.isEmpty
                      ? 'Listening… speak now'
                      : _voiceText,
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: AppColors.primaryBlue),
                ),
              ),
              TextButton(
                onPressed: _toggleListening,
                child: const Text('Done',
                    style: TextStyle(color: AppColors.primaryBlue,
                        fontWeight: FontWeight.w600)),
              ),
            ]),
          ),

        // ── Messages ───────────────────────────────────────────────────
        Expanded(
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            itemCount: _messages.length,
            itemBuilder: (ctx, i) => _ChatBubble(
              message: _messages[i],
              isSpeaking: _speakingId == _messages[i].id && _isSpeaking,
              onSpeak: () => _speak(_messages[i]),
            ),
          ),
        ),

        // ── Therapist strip ────────────────────────────────────────────
        Container(
          margin: const EdgeInsets.fromLTRB(16, 4, 16, 4),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            color: AppColors.primaryBlue.withOpacity(0.07),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.primaryBlue.withOpacity(0.18)),
          ),
          child: Row(children: [
            const Icon(Icons.person_outline,
                color: AppColors.primaryBlue, size: 17),
            const SizedBox(width: 8),
            Expanded(
              child: Text('Talk to a real therapist',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: AppColors.primaryBlue)),
            ),
            const Icon(Icons.arrow_forward_ios,
                size: 11, color: AppColors.primaryBlue),
          ]),
        ),

        // ── Input bar ──────────────────────────────────────────────────
        Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            border: Border(top: BorderSide(color: AppColors.border)),
          ),
          child: SafeArea(
            top: false,
            child: Row(children: [

              // Mic button
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: 46, height: 46,
                decoration: BoxDecoration(
                  color: _isListening
                      ? AppColors.primaryBlue
                      : AppColors.primaryBlue.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: Icon(
                    _isListening ? Icons.mic : Icons.mic_none,
                    color: _isListening
                        ? Colors.white
                        : AppColors.primaryBlue,
                    size: 22,
                  ),
                  onPressed: _toggleListening,
                  tooltip: _isListening ? 'Stop listening' : 'Speak',
                ),
              ),

              const SizedBox(width: 8),

              // Text input
              Expanded(
                child: TextField(
                  controller: _inputCtrl,
                  enabled: !_isStreaming,
                  maxLines: null,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _sendMessage(),
                  decoration: InputDecoration(
                    hintText: _isListening
                        ? 'Listening…'
                        : _isStreaming
                            ? 'Mental Health is thinking…'
                            : 'Type or speak…',
                    hintStyle:
                        const TextStyle(color: AppColors.textSecondary),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                      borderSide: BorderSide(color: AppColors.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                      borderSide: BorderSide(color: AppColors.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                      borderSide: const BorderSide(
                          color: AppColors.primaryBlue, width: 1.5),
                    ),
                    disabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(100),
                      borderSide: BorderSide(
                          color: AppColors.border.withOpacity(0.4)),
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 8),

              // Send button
              GestureDetector(
                onTap: _isStreaming ? null : _sendMessage,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    color: _isStreaming
                        ? AppColors.primaryBlue.withOpacity(0.35)
                        : AppColors.primaryBlue,
                    shape: BoxShape.circle,
                  ),
                  child: _isStreaming
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.send, color: Colors.white, size: 20),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

// ── Chat bubble ───────────────────────────────────────────────────────────────
class _ChatBubble extends StatelessWidget {
  final ChatMessage message;
  final bool        isSpeaking;
  final VoidCallback onSpeak;

  const _ChatBubble({
    required this.message,
    required this.isSpeaking,
    required this.onSpeak,
  });

  @override
  Widget build(BuildContext context) {
    final theme  = Theme.of(context);
    final isUser = message.isUser;

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // AI avatar
          if (!isUser)
            Container(
              width: 32, height: 32,
              margin: const EdgeInsets.only(right: 8, bottom: 2),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [AppColors.primaryBlue, AppColors.accentCoral]),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text('AI',
                    style: TextStyle(color: Colors.white, fontSize: 10,
                        fontWeight: FontWeight.bold)),
              ),
            ),

          // Bubble + speaker button
          Flexible(
            child: Column(
              crossAxisAlignment: isUser
                  ? CrossAxisAlignment.end
                  : CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: message.isError
                        ? AppColors.alertRed.withOpacity(0.08)
                        : isUser
                            ? AppColors.primaryBlue
                            : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(18),
                      topRight: const Radius.circular(18),
                      bottomLeft: Radius.circular(isUser ? 18 : 4),
                      bottomRight: Radius.circular(isUser ? 4 : 18),
                    ),
                    border: isUser
                        ? null
                        : Border.all(
                            color: message.isError
                                ? AppColors.alertRed.withOpacity(0.3)
                                : AppColors.border),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.04),
                          blurRadius: 8, offset: const Offset(0, 2)),
                    ],
                  ),
                  child: message.text.isEmpty
                      // Streaming cursor
                      ? _StreamingCursor()
                      : Text(
                          message.text,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: isUser
                                ? Colors.white
                                : AppColors.textPrimary,
                            height: 1.55,
                          ),
                        ),
                ),

                // Speaker button (AI only, after text is received)
                if (!isUser && message.text.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4, left: 4),
                    child: GestureDetector(
                      onTap: onSpeak,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: isSpeaking
                              ? AppColors.primaryBlue.withOpacity(0.12)
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(100),
                          border: Border.all(
                            color: isSpeaking
                                ? AppColors.primaryBlue.withOpacity(0.3)
                                : Colors.transparent,
                          ),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(
                            isSpeaking
                                ? Icons.stop_circle_outlined
                                : Icons.volume_up_outlined,
                            size: 14,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            isSpeaking ? 'Stop' : 'Listen',
                            style: const TextStyle(
                                fontSize: 11,
                                color: AppColors.textSecondary),
                          ),
                        ]),
                      ),
                    ),
                  ),
              ],
            ),
          ),

          if (isUser) const SizedBox(width: 8),
        ],
      ),
    );
  }
}

// ── Streaming cursor (blinking) ───────────────────────────────────────────────
class _StreamingCursor extends StatefulWidget {
  @override
  State<_StreamingCursor> createState() => _StreamingCursorState();
}

class _StreamingCursorState extends State<_StreamingCursor>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..repeat(reverse: true);
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _ctrl,
      child: Container(width: 8, height: 18,
          decoration: BoxDecoration(
              color: AppColors.textSecondary,
              borderRadius: BorderRadius.circular(2))),
    );
  }
}

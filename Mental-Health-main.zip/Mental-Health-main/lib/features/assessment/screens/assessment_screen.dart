import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class _Question {
  final String text;
  const _Question(this.text);
}

const _questions = [
  _Question('Over the past 2 weeks, how often have you felt down, depressed, or hopeless?'),
  _Question('How often have you had little interest or pleasure in doing things?'),
  _Question('How often have you felt nervous, anxious, or on edge?'),
  _Question('How often have you been unable to stop or control worrying?'),
  _Question('How often have you had trouble falling or staying asleep?'),
  _Question('How often have you felt tired or had little energy?'),
  _Question('How often have you had poor appetite or been overeating?'),
  _Question('How often have you felt bad about yourself or that you\'re a failure?'),
  _Question('How often have you had trouble concentrating on things?'),
];

const _emojis = ['😊', '🙂', '😐', '😔', '😢'];

class AssessmentScreen extends StatefulWidget {
  const AssessmentScreen({super.key});

  @override
  State<AssessmentScreen> createState() => _AssessmentScreenState();
}

class _AssessmentScreenState extends State<AssessmentScreen> {
  int _current = 0;
  int? _selectedEmoji;
  double _intensity = 50;
  final Map<int, Map<String, dynamic>> _answers = {};

  void _next() {
    if (_selectedEmoji == null) return;
    _answers[_current] = {'emoji': _selectedEmoji, 'intensity': _intensity};

    if (_current < _questions.length - 1) {
      setState(() {
        _current++;
        final prev = _answers[_current];
        _selectedEmoji = prev != null ? prev['emoji'] as int : null;
        _intensity = prev != null ? prev['intensity'] as double : 50;
      });
    } else {
      context.go('/app');
    }
  }

  void _back() {
    if (_current > 0) {
      setState(() {
        _current--;
        final prev = _answers[_current];
        _selectedEmoji = prev != null ? prev['emoji'] as int : null;
        _intensity = prev != null ? prev['intensity'] as double : 50;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final progress = (_current + 1) / _questions.length;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header with progress bar
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 32, 32, 24),
              child: Column(
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: _back,
                        child: AnimatedOpacity(
                          opacity: _current > 0 ? 1.0 : 0.35,
                          duration: const Duration(milliseconds: 200),
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: theme.colorScheme.surface,
                              shape: BoxShape.circle,
                              border: Border.all(color: AppColors.border),
                            ),
                            child: const Icon(Icons.chevron_left, size: 20),
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Step ${_current + 1} of ${_questions.length}',
                          textAlign: TextAlign.center,
                          style: theme.textTheme.bodySmall,
                        ),
                      ),
                      TextButton(
                        onPressed: () => context.go('/app'),
                        child: Text('Skip',
                            style: TextStyle(color: AppColors.textSecondary)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: AppColors.muted,
                      valueColor: const AlwaysStoppedAnimation(
                          AppColors.primaryBlue),
                    ),
                  ),
                ],
              ),
            ),

            // Question card
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Text(
                        _questions[_current].text,
                        key: ValueKey(_current),
                        style: theme.textTheme.headlineMedium,
                        textAlign: TextAlign.left,
                      ),
                    ),
                    const SizedBox(height: 40),

                    // Emoji scale
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('How often?',
                            style: theme.textTheme.bodySmall),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: List.generate(_emojis.length, (i) {
                            final selected = _selectedEmoji == i;
                            return GestureDetector(
                              onTap: () =>
                                  setState(() => _selectedEmoji = i),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                width: 56,
                                height: 56,
                                decoration: BoxDecoration(
                                  color: selected
                                      ? AppColors.primaryBlue
                                      : theme.colorScheme.surface,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: selected
                                        ? AppColors.primaryBlue
                                        : AppColors.border,
                                  ),
                                  boxShadow: selected
                                      ? [
                                          BoxShadow(
                                            color: AppColors.primaryBlue
                                                .withOpacity(0.3),
                                            blurRadius: 12,
                                            offset: const Offset(0, 4),
                                          )
                                        ]
                                      : [],
                                ),
                                child: Center(
                                  child: Text(_emojis[i],
                                      style: const TextStyle(fontSize: 26)),
                                ),
                              ),
                            );
                          }),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Never', style: theme.textTheme.bodySmall),
                            Text('Always', style: theme.textTheme.bodySmall),
                          ],
                        ),
                      ],
                    ),

                    // Intensity slider (shown after emoji selected)
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: _selectedEmoji != null
                          ? Padding(
                              key: const ValueKey('slider'),
                              padding: const EdgeInsets.only(top: 32),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('How intense is this feeling?',
                                      style: theme.textTheme.bodySmall),
                                  const SizedBox(height: 12),
                                  SliderTheme(
                                    data: SliderTheme.of(context).copyWith(
                                      activeTrackColor: AppColors.primaryBlue,
                                      inactiveTrackColor: AppColors.muted,
                                      thumbColor: AppColors.primaryBlue,
                                      overlayColor: AppColors.primaryBlue
                                          .withOpacity(0.15),
                                      trackHeight: 4,
                                    ),
                                    child: Slider(
                                      value: _intensity,
                                      min: 0,
                                      max: 100,
                                      onChanged: (v) =>
                                          setState(() => _intensity = v),
                                    ),
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('Mild',
                                          style: theme.textTheme.bodySmall),
                                      Text('Severe',
                                          style: theme.textTheme.bodySmall),
                                    ],
                                  ),
                                ],
                              ),
                            )
                          : const SizedBox(key: ValueKey('empty'), height: 0),
                    ),
                  ],
                ),
              ),
            ),

            // Next button
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 0, 32, 32),
              child: ElevatedButton(
                onPressed: _selectedEmoji != null ? _next : null,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(_current < _questions.length - 1
                        ? 'Next'
                        : 'Complete'),
                    const SizedBox(width: 8),
                    const Icon(Icons.chevron_right, size: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

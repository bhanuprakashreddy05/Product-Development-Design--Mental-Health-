import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class ExerciseDetailScreen extends StatefulWidget {
  final String exerciseId;
  const ExerciseDetailScreen({super.key, required this.exerciseId});

  @override
  State<ExerciseDetailScreen> createState() => _ExerciseDetailScreenState();
}

class _Phase {
  final String name;
  final Duration duration;
  final double scale;
  const _Phase(this.name, this.duration, this.scale);
}

final Map<String, Map<String, dynamic>> _allExerciseData = {
  '1': {
    'title': 'Box Breathing',
    'steps': [
      'Inhale slowly through your nose for 4 seconds',
      'Hold your breath for 4 seconds',
      'Exhale slowly through your mouth for 4 seconds',
      'Hold your breath for 4 seconds',
    ],
    'phases': [
      const _Phase('Inhale', Duration(seconds: 4), 1.4),
      const _Phase('Hold', Duration(seconds: 4), 1.4),
      const _Phase('Exhale', Duration(seconds: 4), 1.0),
      const _Phase('Hold', Duration(seconds: 4), 1.0),
    ],
  },
  '2': {
    'title': '5-4-3-2-1 Grounding',
    'steps': [
      'Acknowledge 5 things you see around you',
      'Acknowledge 4 things you can touch',
      'Acknowledge 3 things you hear',
      'Acknowledge 2 things you can smell',
      'Acknowledge 1 thing you can taste',
    ],
    'phases': [
      const _Phase('Observe', Duration(seconds: 10), 1.1),
      const _Phase('Focus', Duration(seconds: 10), 1.1),
    ],
  },
  '5': {
    'title': '4-7-8 Breathing',
    'steps': [
      'Exhale completely through your mouth',
      'Inhale through your nose for 4 seconds',
      'Hold your breath for 7 seconds',
      'Exhale through your mouth for 8 seconds',
    ],
    'phases': [
      const _Phase('Inhale', Duration(seconds: 4), 1.4),
      const _Phase('Hold', Duration(seconds: 7), 1.4),
      const _Phase('Exhale', Duration(seconds: 8), 1.0),
    ],
  },
};

class _ExerciseDetailScreenState extends State<ExerciseDetailScreen>
    with SingleTickerProviderStateMixin {
  bool _isPlaying = false;
  int _phaseIndex = 0;
  late AnimationController _scaleController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );
    _scaleAnim = Tween<double>(begin: 1.0, end: 1.4).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _scaleController.dispose();
    super.dispose();
  }

  void _togglePlay() {
    setState(() => _isPlaying = !_isPlaying);
    if (_isPlaying) {
      _runPhase(0);
    } else {
      _scaleController.stop();
      setState(() => _phaseIndex = 0);
      _scaleController.reset();
    }
  }

  void _runPhase(int index) {
    if (!_isPlaying || !mounted) return;
    final phases = _allExerciseData[widget.exerciseId]?['phases'] as List<_Phase>? ?? [];
    if (phases.isEmpty) return;
    final phase = phases[index % phases.length];
    setState(() => _phaseIndex = index % phases.length);

    _scaleController.duration = phase.duration;

    if (phase.scale > 1.0) {
      _scaleController.forward(from: _scaleController.value);
    } else {
      _scaleController.reverse(from: _scaleController.value);
    }

    Future.delayed(phase.duration, () {
      if (!mounted || !_isPlaying) return;
      _runPhase((index + 1) % phases.length);
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.primaryBlue.withOpacity(0.12),
              theme.scaffoldBackgroundColor,
              AppColors.accentCoral.withOpacity(0.08),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => context.go('/app/exercises'),
                      child: Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surface,
                          shape: BoxShape.circle,
                          border: Border.all(color: AppColors.border),
                        ),
                        child: const Icon(Icons.chevron_left, size: 22),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                        _allExerciseData[widget.exerciseId]?['title'] as String? ?? 'Exercise',
                        style: theme.textTheme.headlineSmall),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 40),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 260,
                          height: 260,
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              AnimatedBuilder(
                                animation: _scaleAnim,
                                builder: (_, __) => Transform.scale(
                                  scale: _scaleAnim.value,
                                  child: Container(
                                    width: 220,
                                    height: 220,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: RadialGradient(
                                        colors: [
                                          Color(0x335B7FFF),
                                          Color(0x005B7FFF),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              AnimatedBuilder(
                                animation: _scaleAnim,
                                builder: (_, __) => Transform.scale(
                                  scale: _scaleAnim.value,
                                  child: Container(
                                    width: 180,
                                    height: 180,
                                    decoration: const BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          AppColors.primaryBlue,
                                          AppColors.accentCoral,
                                        ],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x405B7FFF),
                                          blurRadius: 40,
                                          offset: Offset(0, 12),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 400),
                                    child: Text(
                                      ((_allExerciseData[widget.exerciseId]?['phases'] as List<_Phase>?)?[_phaseIndex])?.name ?? 'Breathe',
                                      key: ValueKey(_phaseIndex),
                                      style: const TextStyle(
                                        fontSize: 28,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                        fontFamily: 'Fraunces',
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  const Text(
                                    'Follow the circle',
                                    style: TextStyle(
                                      fontSize: 13,
                                      color: Colors.white70,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 48),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 32),
                          child: Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.surface.withOpacity(0.85),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(color: AppColors.border),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('How it works:',
                                    style: theme.textTheme.titleMedium),
                                const SizedBox(height: 12),
                                ..._buildSteps(theme),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 40),
                        GestureDetector(
                          onTap: _togglePlay,
                          child: Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              color: AppColors.primaryBlue,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryBlue.withOpacity(0.4),
                                  blurRadius: 24,
                                  offset: const Offset(0, 8),
                                ),
                              ],
                            ),
                            child: Icon(
                              _isPlaying ? Icons.pause : Icons.play_arrow,
                              color: Colors.white,
                              size: 36,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildSteps(ThemeData theme) {
    final steps = _allExerciseData[widget.exerciseId]?['steps'] as List<String>? ?? [];
    return steps.asMap().entries.map((e) {
      return Padding(
        padding: EdgeInsets.only(bottom: e.key < steps.length - 1 ? 10 : 0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${e.key + 1}. ',
                style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
            Expanded(
              child: Text(e.value,
                  style: theme.textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary)),
            ),
          ],
        ),
      );
    }).toList();
  }
}

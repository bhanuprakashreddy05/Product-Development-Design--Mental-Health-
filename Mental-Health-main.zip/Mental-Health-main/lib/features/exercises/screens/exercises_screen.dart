import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class Exercise {
  final String id;
  final String title;
  final String category;
  final String duration;
  final String difficulty;
  final IconData icon;
  final List<Color> gradientColors;
  final String description;

  const Exercise({
    required this.id,
    required this.title,
    required this.category,
    required this.duration,
    required this.difficulty,
    required this.icon,
    required this.gradientColors,
    required this.description,
  });
}

const exercises = [
  Exercise(
    id: '1',
    title: 'Box Breathing',
    category: 'Breathing',
    duration: '5 min',
    difficulty: 'Easy',
    icon: Icons.air,
    gradientColors: [Color(0x335B7FFF), Color(0x0D5B7FFF)],
    description: 'A simple breathing technique to calm anxiety and improve focus.',
  ),
  Exercise(
    id: '2',
    title: '5-4-3-2-1 Grounding',
    category: 'Grounding',
    duration: '7 min',
    difficulty: 'Easy',
    icon: Icons.anchor,
    gradientColors: [Color(0x334CAF82), Color(0x0D4CAF82)],
    description: 'Connect with your senses to anchor yourself in the present moment.',
  ),
  Exercise(
    id: '3',
    title: 'Body Scan Meditation',
    category: 'Meditation',
    duration: '15 min',
    difficulty: 'Medium',
    icon: Icons.self_improvement,
    gradientColors: [Color(0x33FF8C69), Color(0x0DFF8C69)],
    description: 'Progressive relaxation technique to release tension.',
  ),
  Exercise(
    id: '4',
    title: 'Gratitude Journaling',
    category: 'Journaling',
    duration: '10 min',
    difficulty: 'Easy',
    icon: Icons.edit_note,
    gradientColors: [Color(0x335B7FFF), Color(0x0D5B7FFF)],
    description: 'Shift your focus to the positive aspects of your life.',
  ),
  Exercise(
    id: '5',
    title: '4-7-8 Breathing',
    category: 'Breathing',
    duration: '3 min',
    difficulty: 'Easy',
    icon: Icons.air,
    gradientColors: [Color(0x335B7FFF), Color(0x0D5B7FFF)],
    description: 'Quick breathing exercise to reduce stress and promote sleep.',
  ),
  Exercise(
    id: '6',
    title: 'Thought Record',
    category: 'Journaling',
    duration: '12 min',
    difficulty: 'Medium',
    icon: Icons.psychology_outlined,
    gradientColors: [Color(0x335B7FFF), Color(0x0D5B7FFF)],
    description: 'CBT technique to challenge negative thought patterns.',
  ),
];

const _categories = ['All', 'Breathing', 'Grounding', 'Meditation', 'Journaling'];

class ExercisesScreen extends StatefulWidget {
  const ExercisesScreen({super.key});

  @override
  State<ExercisesScreen> createState() => _ExercisesScreenState();
}

class _ExercisesScreenState extends State<ExercisesScreen> {
  String _selectedCategory = 'All';

  List<Exercise> get _filtered => _selectedCategory == 'All'
      ? exercises
      : exercises.where((e) => e.category == _selectedCategory).toList();

  Color _difficultyColor(String d) {
    switch (d) {
      case 'Easy':
        return AppColors.successMint;
      case 'Medium':
        return AppColors.accentCoral;
      default:
        return AppColors.alertRed;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Column(
        children: [
          // Header + category tabs
          SafeArea(
            bottom: false,
            child: Container(
              decoration: BoxDecoration(
                color: theme.colorScheme.surface,
                border:
                    Border(bottom: BorderSide(color: AppColors.border)),
              ),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 16, 24, 12),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () => context.go('/app'),
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: theme.scaffoldBackgroundColor,
                              shape: BoxShape.circle,
                            ),
                            child:
                                const Icon(Icons.chevron_left, size: 22),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text('CBT Exercises',
                            style: theme.textTheme.headlineSmall),
                      ],
                    ),
                  ),

                  // Category filter
                  SizedBox(
                    height: 44,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      itemCount: _categories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 8),
                      itemBuilder: (ctx, i) {
                        final cat = _categories[i];
                        final active = _selectedCategory == cat;
                        return GestureDetector(
                          onTap: () =>
                              setState(() => _selectedCategory = cat),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              color: active
                                  ? AppColors.primaryBlue
                                  : theme.scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(100),
                              border: Border.all(
                                color: active
                                    ? AppColors.primaryBlue
                                    : AppColors.border,
                              ),
                            ),
                            child: Text(
                              cat,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: active
                                    ? Colors.white
                                    : theme.textTheme.bodyMedium?.color ?? AppColors.textPrimary,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),

          // Exercise list
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(24),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                mainAxisExtent: 210, // Fixed height for consistency
              ),
              itemCount: _filtered.length,
              itemBuilder: (ctx, i) {
                final ex = _filtered[i];
                return _ExerciseCard(
                  exercise: ex,
                  difficultyColor: _difficultyColor(ex.difficulty),
                  onTap: () => context.go('/app/exercises/${ex.id}'),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ExerciseCard extends StatelessWidget {
  final Exercise exercise;
  final Color difficultyColor;
  final VoidCallback onTap;

  const _ExerciseCard({
    required this.exercise,
    required this.difficultyColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.02),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: exercise.gradientColors,
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(exercise.icon,
                  color: AppColors.primaryBlue, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              exercise.title,
              style: theme.textTheme.titleSmall?.copyWith(
                fontWeight: FontWeight.w700,
                fontSize: 14.5,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Expanded(
              child: Text(
                exercise.description,
                style: theme.textTheme.bodySmall?.copyWith(
                  height: 1.4,
                  fontSize: 11,
                  color: AppColors.textSecondary,
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.access_time,
                        size: 12, color: AppColors.textSecondary),
                    const SizedBox(width: 4),
                    Text(
                      exercise.duration,
                      style: theme.textTheme.bodySmall?.copyWith(fontSize: 10.5),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: difficultyColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text(
                    exercise.difficulty,
                    style: TextStyle(
                      fontSize: 10,
                      color: difficultyColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/providers/user_provider.dart';
import 'weekly_mood_detail_screen.dart';
import 'mood_distribution_screen.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final userName = ref.watch(userDisplayNameProvider);
    final user = ref.watch(authStateProvider).value;
    final userEmail = user?.email ?? '-';
    final photoUrl = user?.photoURL;
    final initial = userName.isNotEmpty ? userName[0].toUpperCase() : 'U';

    final isDark = ref.watch(themeModeProvider).value == ThemeMode.dark;
    final settings = ref.watch(settingsProvider).value ?? {};
    final bool notifications = settings['notifications'] == true;
    final currentStreak = ref.watch(streakProvider);
    final totalLogs = ref.watch(moodLogProvider).length;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            SafeArea(
              bottom: false,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  border: Border(bottom: BorderSide(color: AppColors.border)),
                ),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Profile & Settings',
                      style: theme.textTheme.headlineSmall),
                ),
              ),
            ),

            // Profile Card (matching the image)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppColors.primaryBlue.withOpacity(0.04),
                      AppColors.accentCoral.withOpacity(0.06),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: AppColors.border.withOpacity(0.5), width: 1),
                ),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () => ref.read(userProfileProvider.notifier).updateProfileImage(),
                      child: Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: photoUrl == null ? const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [AppColors.primaryBlue, AppColors.accentCoral],
                              ) : null,
                              image: photoUrl != null 
                                ? DecorationImage(
                                    image: FileImage(File(photoUrl)),
                                    fit: BoxFit.cover,
                                  )
                                : null,
                            ),
                            child: photoUrl == null ? Center(
                              child: Text(initial,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 32,
                                      fontWeight: FontWeight.w400)),
                            ) : null,
                          ),
                          Container(
                            padding: const EdgeInsets.all(4),
                            decoration: const BoxDecoration(
                              color: AppColors.primaryBlue,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.camera_alt_outlined, size: 14, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(userName,
                              style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w600)),
                          const SizedBox(height: 2),
                          Text(userEmail,
                              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.primaryBlue.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: const Text(
                              'Mental Health Member',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: AppColors.primaryBlue,
                                  fontWeight: FontWeight.w500),
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit_outlined, color: AppColors.textSecondary, size: 20),
                      onPressed: () => _showEditProfile(context),
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  // ── General ─────────────────────────────────────────
                  const _SectionLabel('GENERAL'),
                  _SettingsCard(children: [
                    _ToggleRow(
                      icon: Icons.notifications_none,
                      label: 'Notifications',
                      subtitle: notifications ? 'Daily reminders on' : 'Daily reminders off',
                      value: notifications,
                      onChanged: (v) => ref.read(settingsProvider.notifier).setNotifications(v),
                    ),
                    _Divider(),
                    _ToggleRow(
                      icon: Icons.dark_mode_outlined,
                      label: 'Dark Mode',
                      subtitle: isDark ? 'Dark theme active' : 'Light theme active',
                      value: isDark,
                      onChanged: (v) => ref.read(themeModeProvider.notifier).setDarkMode(v),
                    ),
                  ]),
                  const SizedBox(height: 24),

                  // ── Your Stats ────────────────────────────────────
                  const _SectionLabel('YOUR STATS'),
                  _SettingsCard(children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const MoodDistributionScreen(),
                                ),
                              ),
                              child: _StatItem(
                                icon: Icons.edit_note,
                                iconColor: AppColors.primaryBlue,
                                value: totalLogs.toString(),
                                label: 'Total Logs',
                              ),
                            ),
                          ),
                          Container(width: 1, height: 40, color: AppColors.border),
                          Expanded(
                            child: GestureDetector(
                              onTap: () => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => const WeeklyMoodDetailScreen(),
                                ),
                              ),
                              child: _StatItem(
                                icon: Icons.mood,
                                iconColor: AppColors.successMint,
                                value:
                                    '${(ref.watch(moodLogProvider.notifier).weeklyAverage() ?? 0).round()}%',
                                label: 'This Week',
                              ),
                            ),
                          ),
                          Container(width: 1, height: 40, color: AppColors.border),
                          Expanded(
                            child: _StatItem(
                              icon: Icons.local_fire_department,
                              iconColor: AppColors.accentCoral,
                              value: currentStreak.toString(),
                              label: 'Day Streak',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]),
                  const SizedBox(height: 24),

                  // ── Settings ──────────────────────────────
                  const _SectionLabel('ACCOUNT & SECURITY'),
                  _SettingsCard(children: [
                    _NavRow(
                      icon: Icons.person_outline,
                      label: 'Edit Profile',
                      onTap: () => _showEditProfile(context),
                    ),
                    _Divider(),
                    _NavRow(
                      icon: Icons.lock_outline,
                      label: 'Change Password',
                      onTap: () => _showChangePassword(context),
                    ),
                    _Divider(),
                    _NavRow(
                      icon: Icons.exit_to_app,
                      label: 'Log Out',
                      color: AppColors.alertRed,
                      onTap: () {
                         showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('Log Out?'),
                            content: const Text('Are you sure you want to log out of Mental Health?'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                              TextButton(
                                onPressed: () async {
                                  await FirebaseAuth.instance.signOut();
                                  if (mounted) {
                                    context.go('/auth');
                                  }
                                },
                                child: const Text('Log Out', style: TextStyle(color: AppColors.alertRed)),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ]),
                  const SizedBox(height: 24),

                  // ── Data ──────────────────────────────
                  const _SectionLabel('DATA & PRIVACY'),
                  _SettingsCard(children: [
                    _NavRow(
                      icon: Icons.delete_outline,
                      label: 'Delete All Mood Data',
                      color: AppColors.alertRed,
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('Delete Data?'),
                            content: const Text('This will permanently delete all your mood history. This action cannot be undone.'),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
                              TextButton(
                                onPressed: () async {
                                  Navigator.pop(ctx);
                                  await ref.read(moodLogProvider.notifier).clearData();
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('All data deleted successfully')),
                                    );
                                  }
                                },
                                child: const Text('Delete', style: TextStyle(color: AppColors.alertRed)),
                              ),
                            ],
                          ),
                        );
                      },
                    ),

                  ]),


                  const SizedBox(height: 40),

                  // ── Version ─────────────────────────────────────────────
                  const Text('Mental Health v1.0.0',
                      style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w400)),
                  const SizedBox(height: 12),
                  const Text('Terms of Service • Privacy Policy',
                      style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w400)),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Feature coming soon!')),
    );
  }

  void _showEditProfile(BuildContext context) {
    final user = ref.read(authStateProvider).value;
    final nameController = TextEditingController(text: user?.displayName ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Profile'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(
            labelText: 'Full Name',
            hintText: 'Enter your name',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              if (nameController.text.trim().isNotEmpty) {
                final nav = Navigator.of(ctx);
                await ref.read(userProfileProvider.notifier).updateDisplayName(nameController.text.trim());
                nav.pop();
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Profile updated successfully')),
                  );
                }
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showChangePassword(BuildContext context) {
    final passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Password'),
        content: TextField(
          controller: passwordController,
          decoration: const InputDecoration(
            labelText: 'New Password',
            hintText: 'Enter new password',
          ),
          obscureText: true,
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              if (passwordController.text.length >= 6) {
                final nav = Navigator.of(ctx);
                try {
                  await ref.read(userProfileProvider.notifier).updatePassword(passwordController.text);
                  nav.pop();
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Password updated successfully')),
                    );
                  }
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error: ${e.toString()}')),
                  );
                }
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Password must be at least 6 characters')),
                );
              }
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }
}


// ── Helper widgets ────────────────────────────────────────────────────────────
class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Text(
          text.toUpperCase(),
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  final List<Widget> children;
  const _SettingsCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(children: children),
    );
  }
}

class _ToggleRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _ToggleRow({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Row(
        children: [
          Icon(icon, color: AppColors.textSecondary, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(fontWeight: FontWeight.w500, fontSize: 15)),
                Text(subtitle,
                    style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
              ],
            ),
          ),
          Switch(
              value: value,
              onChanged: onChanged,
              activeColor: AppColors.primaryBlue),
        ],
      ),
    );
  }
}

class _NavRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _NavRow({
    required this.icon, 
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Icon(icon, color: color ?? AppColors.textSecondary, size: 22),
            const SizedBox(width: 16),
            Expanded(
              child: Text(label,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontWeight: FontWeight.w500, fontSize: 15, color: color ?? AppColors.textPrimary)),
            ),
            const Icon(Icons.chevron_right,
                color: AppColors.textSecondary, size: 20),
          ],
        ),
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Divider(
        height: 1, thickness: 1, color: AppColors.border, indent: 56);
  }
}

class _StatItem extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String value;
  final String label;

  const _StatItem({
    required this.icon,
    required this.iconColor,
    required this.value,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: iconColor.withOpacity(0.12),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: iconColor, size: 22),
        ),
        const SizedBox(height: 10),
        Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: iconColor)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w500)),
      ],
    );
  }
}

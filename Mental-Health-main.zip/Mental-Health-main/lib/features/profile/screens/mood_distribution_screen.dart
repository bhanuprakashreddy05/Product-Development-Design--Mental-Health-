import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/providers/user_provider.dart';

class MoodDistributionScreen extends ConsumerWidget {
  const MoodDistributionScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final moodLogs = ref.watch(moodLogProvider);
    
    // Calculate emoji distribution
    final Map<String, int> emojiCounts = {};
    for (var log in moodLogs) {
      emojiCounts[log.emoji] = (emojiCounts[log.emoji] ?? 0) + 1;
    }
    
    final sortedEmojis = emojiCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Mood Distribution'),
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        foregroundColor: AppColors.textPrimary,
        centerTitle: true,
      ),
      body: moodLogs.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.mood_bad_outlined, size: 64, color: AppColors.textSecondary),
                  const SizedBox(height: 16),
                  Text(
                    'No mood logs yet!',
                    style: theme.textTheme.titleMedium?.copyWith(color: AppColors.textSecondary),
                  ),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Emoji Insights',
                    style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Visualize the feelings you have logged over time.',
                    style: theme.textTheme.bodyMedium?.copyWith(color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 32),
                  
                  // Pie Chart
                  Container(
                    height: 300,
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: PieChart(
                      PieChartData(
                        sectionsSpace: 4,
                        centerSpaceRadius: 50,
                        sections: _createPieSections(emojiCounts),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  
                  // Legend list
                  Text(
                    'Breakdown',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 16),
                  ...sortedEmojis.map((e) => _EmojiRow(
                        emoji: e.key,
                        count: e.value,
                        percentage: (e.value / moodLogs.length * 100),
                        total: moodLogs.length,
                      )),
                ],
              ),
            ),
    );
  }

  List<PieChartSectionData> _createPieSections(Map<String, int> counts) {
    final colors = [
      AppColors.primaryBlue,
      AppColors.successMint,
      AppColors.accentCoral,
      const Color(0xFFA78BFA), // Violet
      const Color(0xFFFFB236), // Amber
      const Color(0xFFFF5252), // Light Red
    ];
    
    int index = 0;
    return counts.entries.map((e) {
      final color = colors[index % colors.length];
      index++;
      return PieChartSectionData(
        color: color,
        value: e.value.toDouble(),
        title: '${e.key}',
        radius: 60,
        titleStyle: const TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      );
    }).toList();
  }
}

class _EmojiRow extends StatelessWidget {
  final String emoji;
  final int count;
  final double percentage;
  final int total;

  const _EmojiRow({
    required this.emoji,
    required this.count,
    required this.percentage,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 28)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _getMoodName(emoji),
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
                Text(
                  '$count logs',
                  style: const TextStyle(
                    fontSize: 13,
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${percentage.toStringAsFixed(1)}%',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
              color: AppColors.primaryBlue,
            ),
          ),
        ],
      ),
    );
  }

  String _getMoodName(String emoji) {
    switch (emoji) {
      case '😊': return 'Happy';
      case '😔': return 'Sad';
      case '😠': return 'Angry';
      case '😰': return 'Anxious';
      case '🧘': return 'Calm';
      case '😴': return 'Tired';
      default: return 'Other';
    }
  }
}

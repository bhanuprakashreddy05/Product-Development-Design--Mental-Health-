import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/providers/user_provider.dart';

class JournalScreen extends ConsumerStatefulWidget {
  const JournalScreen({super.key});

  @override
  ConsumerState<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends ConsumerState<JournalScreen> with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _showAddNoteDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _NewNoteSheet(
        onSave: (text) async {
          final entry = MoodEntry(
            date: DateTime.now(),
            emoji: '📝',
            label: 'Note',
            intensity: 50,
            tags: ['Journal'],
            note: text,
          );
          await ref.read(moodLogProvider.notifier).add(entry);
        },
      ),
    );
  }

  String _formatDate(DateTime date) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final allLogs = ref.watch(moodLogProvider);
    
    // Filter logs that have notes
    final notes = allLogs.where((log) => log.note.isNotEmpty).toList();

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: const Text('Notes'),
        automaticallyImplyLeading: false,
        backgroundColor: theme.colorScheme.surface,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _showAddNoteDialog,
            icon: const Icon(Icons.add_circle_outline, color: AppColors.primaryBlue),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: notes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.note_alt_outlined, size: 64, color: AppColors.textSecondary.withOpacity(0.3)),
                  const SizedBox(height: 16),
                  Text('No notes yet', style: theme.textTheme.titleMedium?.copyWith(color: AppColors.textSecondary)),
                  const SizedBox(height: 8),
                  const Text('Tap + to describe your mood and save memories', 
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: notes.length,
              itemBuilder: (context, index) {
                final note = notes[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text(note.emoji, style: const TextStyle(fontSize: 16)),
                              const SizedBox(width: 8),
                              Text(_formatDate(note.date), style: theme.textTheme.labelSmall),
                            ],
                          ),
                          Row(
                            children: [
                              const Icon(Icons.history, size: 14, color: AppColors.textSecondary),
                              if (note.id != null) ...[
                                const SizedBox(width: 12),
                                GestureDetector(
                                  onTap: () async {
                                    final confirmed = await showDialog<bool>(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        title: const Text('Delete Note?'),
                                        content: const Text('This action cannot be undone.'),
                                        actions: [
                                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                                          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: AppColors.alertRed))),
                                        ],
                                      ),
                                    );
                                    if (confirmed == true) {
                                      await ref.read(moodLogProvider.notifier).delete(note.id!);
                                    }
                                  },
                                  child: const Icon(Icons.delete_outline, size: 18, color: AppColors.alertRed),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(note.note, style: theme.textTheme.bodyMedium?.copyWith(height: 1.5)),
                    ],
                  ),
                );
              },
            ),
      
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 100), // Higher up to clear floating nav
        child: FloatingActionButton(
          onPressed: _showAddNoteDialog,
          backgroundColor: AppColors.primaryBlue,
          elevation: 4,
          shape: const CircleBorder(),
          child: const Icon(Icons.add, color: Colors.white, size: 32),
        ),
      ),
    );
  }
}

class _NewNoteSheet extends StatefulWidget {
  final Future<void> Function(String) onSave;
  const _NewNoteSheet({required this.onSave});

  @override
  State<_NewNoteSheet> createState() => _NewNoteSheetState();
}

class _NewNoteSheetState extends State<_NewNoteSheet> with SingleTickerProviderStateMixin {
  final _textController = TextEditingController();
  final _stt = SpeechToText();
  bool _isListening = false;
  bool _sttAvailable = false;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _initStt();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.25).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  Future<void> _initStt() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      _sttAvailable = await _stt.initialize(
        onError: (e) => debugPrint('STT Error: $e'),
        onStatus: (s) {
          if (s == 'notListening' || s == 'done') {
            if (mounted) {
              setState(() => _isListening = false);
              _pulseController.stop();
            }
          }
        },
      );
      if (mounted) setState(() {});
    }
  }

  void _toggleListening() async {
    if (_isListening) {
      await _stt.stop();
      return;
    }
    if (!_sttAvailable) return;

    if (mounted) {
      setState(() => _isListening = true);
      _pulseController.repeat(reverse: true);
    }
    
    await _stt.listen(
      onResult: (result) {
        if (mounted) {
          setState(() {
            _textController.text = result.recognizedWords;
            _textController.selection = TextSelection.fromPosition(
              TextPosition(offset: _textController.text.length),
            );
          });
        }
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
    );
  }

  @override
  void dispose() {
    _stt.stop();
    _textController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.fromLTRB(24, 24, 24, MediaQuery.of(context).viewInsets.bottom + 24),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('How about your mood? ⛅', style: theme.textTheme.headlineSmall),
              IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close)),
            ],
          ),
          const SizedBox(height: 8),
          const Text('Describe your mood to save your memories...', 
              style: TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          const SizedBox(height: 24),
          TextField(
            controller: _textController,
            maxLines: 6,
            autofocus: true,
            decoration: InputDecoration(
              hintText: "I'm feeling...",
              filled: true,
              fillColor: theme.scaffoldBackgroundColor,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
              contentPadding: const EdgeInsets.all(20),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: _toggleListening,
                child: ScaleTransition(
                  scale: _isListening ? _pulseAnimation : const AlwaysStoppedAnimation(1.0),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _isListening ? AppColors.accentCoral : AppColors.primaryBlue.withOpacity(0.1),
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primaryBlue.withOpacity(0.3)),
                    ),
                    child: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      color: _isListening ? Colors.white : AppColors.primaryBlue,
                      size: 28,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: ElevatedButton(
                  onPressed: () async {
                    if (_textController.text.trim().isNotEmpty) {
                      final text = _textController.text.trim();
                      Navigator.pop(context); // Pop first to avoid context issues
                      await widget.onSave(text);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 18),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  ),
                  child: const Text('Save Memory'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}


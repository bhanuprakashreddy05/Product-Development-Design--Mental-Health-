import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/user_provider.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final userName = ref.watch(userDisplayNameProvider);
    final moodLogsNotifier = ref.watch(moodLogProvider.notifier);
    final moodScore = (moodLogsNotifier.todayAverage() ?? moodLogsNotifier.weeklyAverage() ?? 0).round();
    final currentStreak = ref.watch(streakProvider);
    final String greeting = _getGreeting();

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Stack(
        children: [
          // Dynamic Background Accent
          Positioned(
            top: -100,
            right: -50,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    AppColors.primaryBlue.withOpacity(0.08),
                    AppColors.primaryBlue.withOpacity(0),
                  ],
                ),
              ),
            ),
          ),
          
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // Top App Bar Area
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(28, 24, 28, 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(greeting, 
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: AppColors.textSecondary,
                                fontWeight: FontWeight.w500,
                              )),
                            const SizedBox(height: 2),
                            Text(userName.split(' ')[0], 
                              style: theme.textTheme.displayMedium),
                          ],
                        ),
                        Container(
                          padding: const EdgeInsets.all(2),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: AppColors.border, width: 2),
                          ),
                          child: const CircleAvatar(
                            radius: 20,
                            backgroundColor: AppColors.primaryLight,
                            child: Icon(Icons.person_rounded, color: AppColors.primaryBlue, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Featured Mood Card
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 16, 24, 28),
                    child: Container(
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [AppColors.primaryBlue, Color(0xFF6B8AFF)],
                        ),
                        borderRadius: BorderRadius.circular(32),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primaryBlue.withOpacity(0.3),
                            blurRadius: 24,
                            offset: const Offset(0, 12),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text('Daily Mood Score',
                                    style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600)),
                                  const SizedBox(height: 6),
                                  Text('$moodScore%',
                                    style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
                                ],
                              ),
                              _MoodIndicatorCircle(score: moodScore),
                            ],
                          ),
                          const SizedBox(height: 24),
                          const Text('“Your mental health is a priority. Your happiness is an essential. Your self-care is a necessity.”',
                            style: TextStyle(color: Colors.white, fontSize: 13, height: 1.6, fontStyle: FontStyle.italic)),
                          const SizedBox(height: 28),
                          ElevatedButton(
                            onPressed: () => context.go('/app/mood'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.white,
                              foregroundColor: AppColors.primaryBlue,
                              minimumSize: const Size(double.infinity, 54),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.add_circle_outline, size: 20),
                                SizedBox(width: 10),
                                Text('Log Today\'s Mood'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                // Stats Section
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Row(
                      children: [
                        Expanded(
                          child: _SmallStatCard(
                            label: 'Focus Streak',
                            value: '$currentStreak Days',
                            iconColor: AppColors.accentCoral,
                            icon: Icons.local_fire_department_rounded,
                            onTap: () => context.go('/app/progress'),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: _SmallStatCard(
                            label: 'Consistency',
                            value: 'Excellent',
                            iconColor: AppColors.accentMint,
                            icon: Icons.auto_awesome_rounded,
                            onTap: () => context.go('/app/progress'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Quick Actions Title
                const SliverPadding(
                  padding: EdgeInsets.fromLTRB(28, 36, 28, 20),
                  sliver: SliverToBoxAdapter(
                    child: Text('Self-Care Tools', style: TextStyle(
                      fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: -0.5
                    )),
                  ),
                ),

                // Tools Grid
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  sliver: SliverGrid(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 16,
                      crossAxisSpacing: 16,
                      childAspectRatio: 0.95,
                    ),
                    delegate: SliverChildListDelegate([
                      _ToolCard(
                        title: 'Voice Journal',
                        subtitle: 'Spoken reflection',
                        icon: Icons.keyboard_voice_rounded,
                        color: const Color(0xFF6366F1),
                        onTap: () => context.go('/app/journal'),
                      ),
                      _ToolCard(
                        title: 'Exercises',
                        subtitle: 'Mindful breathing',
                        icon: Icons.spa_rounded,
                        color: AppColors.accentMint,
                        onTap: () => context.go('/app/exercises'),
                      ),
                      _ToolCard(
                        title: 'Crisis Support',
                        subtitle: 'Talk now',
                        icon: Icons.emergency_rounded,
                        color: AppColors.error,
                        onTap: () => context.go('/app/crisis'),
                      ),
                      _ToolCard(
                        title: 'Insights',
                        subtitle: 'Data trends',
                        icon: Icons.analytics_rounded,
                        color: AppColors.accentCoral,
                        onTap: () => context.go('/app/progress'),
                      ),
                    ]),
                  ),
                ),

                const SliverToBoxAdapter(child: SizedBox(height: 100)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }
}

class _SmallStatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;
  final VoidCallback onTap;

  const _SmallStatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: iconColor, size: 20),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontWeight: FontWeight.w600)),
                Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const _ToolCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const Spacer(),
            Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
          ],
        ),
      ),
    );
  }
}

class _MoodIndicatorCircle extends StatelessWidget {
  final int score;
  const _MoodIndicatorCircle({required this.score});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 50,
      height: 50,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: score / 100,
            strokeWidth: 3.5,
            backgroundColor: Colors.white.withOpacity(0.2),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
          ),
          Icon(
            score > 70 ? Icons.sentiment_very_satisfied_rounded : 
            score > 40 ? Icons.sentiment_satisfied_rounded : Icons.sentiment_dissatisfied_rounded,
            color: Colors.white,
            size: 20,
          ),
        ],
      ),
    );
  }
}

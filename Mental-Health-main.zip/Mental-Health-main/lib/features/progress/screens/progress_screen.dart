import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../../core/theme/app_theme.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/user_provider.dart';
import 'dart:io';
import 'package:external_path/external_path.dart';
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class ProgressScreen extends ConsumerWidget {
  const ProgressScreen({super.key});

  static const _days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final moodLogsNotifier = ref.watch(moodLogProvider.notifier);

    final avgMood = moodLogsNotifier.weeklyAverage()?.round() ?? 0;
    final topTag = moodLogsNotifier.topTag() ?? 'tracking';

    final weeklyIntensities = moodLogsNotifier.weeklyIntensities();
    final moodData = <FlSpot>[];
    for (int i = 0; i < 7; i++) {
      final intensity = weeklyIntensities[i] ?? 0.0;
      moodData.add(FlSpot(i.toDouble(), intensity));
    }

    // Determine trend: compare first half vs second half of the week
    final firstHalf = [0, 1, 2].map((i) => weeklyIntensities[i] ?? 0.0).toList();
    final secondHalf = [4, 5, 6].map((i) => weeklyIntensities[i] ?? 0.0).toList();
    final firstAvg = firstHalf.isEmpty ? 0.0 : firstHalf.reduce((a, b) => a + b) / firstHalf.length;
    final secondAvg = secondHalf.isEmpty ? 0.0 : secondHalf.reduce((a, b) => a + b) / secondHalf.length;
    final trendDelta = secondAvg - firstAvg;
    final isTrendingUp = trendDelta > 5;
    final isTrendingDown = trendDelta < -5;

    final heatmap = moodLogsNotifier.heatmap28();

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SafeArea(
              bottom: false,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  border: Border(bottom: BorderSide(color: AppColors.border)),
                ),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Progress & Insights',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      )),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Weekly Mood Trend',
                                      style: theme.textTheme.titleMedium),
                                  const SizedBox(height: 4),
                                  RichText(
                                    text: TextSpan(
                                      text: 'Your average mood: ',
                                      style: theme.textTheme.bodySmall,
                                      children: [
                                        TextSpan(
                                          text: '$avgMood/100',
                                          style: const TextStyle(
                                            color: AppColors.primaryBlue,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              children: [
                                const Icon(Icons.trending_up,
                                    color: AppColors.successMint, size: 16),
                                const SizedBox(width: 4),
                                Text('+8%',
                                    style: const TextStyle(
                                        color: AppColors.successMint,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13)),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 24),
                        SizedBox(
                          height: 180,
                          child: LineChart(
                            LineChartData(
                              gridData: FlGridData(
                                show: true,
                                drawVerticalLine: false,
                                getDrawingHorizontalLine: (value) => FlLine(
                                  color: AppColors.border,
                                  strokeWidth: 0.8,
                                ),
                              ),
                              titlesData: FlTitlesData(
                                topTitles: const AxisTitles(
                                    sideTitles: SideTitles(showTitles: false)),
                                rightTitles: const AxisTitles(
                                    sideTitles: SideTitles(showTitles: false)),
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    interval: 20,
                                    getTitlesWidget: (value, _) => Text(
                                      '${value.toInt()}',
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color: AppColors.textSecondary),
                                    ),
                                  ),
                                ),
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    getTitlesWidget: (value, _) {
                                      final i = value.toInt();
                                      if (i < 0 || i >= _days.length) {
                                        return const SizedBox.shrink();
                                      }
                                      return Text(_days[i],
                                          style: const TextStyle(
                                              fontSize: 11,
                                              color: AppColors.textSecondary));
                                    },
                                  ),
                                ),
                              ),
                              borderData: FlBorderData(show: false),
                              minY: 0,
                              maxY: 100,
                              lineBarsData: [
                                LineChartBarData(
                                  spots: moodData.isEmpty
                                      ? [const FlSpot(0, 0)]
                                      : moodData,
                                  isCurved: true,
                                  color: AppColors.primaryBlue,
                                  barWidth: 3,
                                  belowBarData: BarAreaData(
                                    show: true,
                                    gradient: LinearGradient(
                                      begin: Alignment.topCenter,
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        AppColors.primaryBlue.withOpacity(0.2),
                                        Colors.transparent,
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _MoodTipsCard(
                    isTrendingUp: isTrendingUp,
                    isTrendingDown: isTrendingDown,
                  ),
                  const SizedBox(height: 16),
                  _Card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Activity Heatmap',
                            style: theme.textTheme.titleMedium),
                        const SizedBox(height: 16),
                        GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 7,
                            crossAxisSpacing: 6,
                            mainAxisSpacing: 6,
                          ),
                          itemCount: heatmap.length,
                          itemBuilder: (ctx, i) => Container(
                            decoration: BoxDecoration(
                              color: heatmap[i] == 1
                                  ? AppColors.primaryBlue
                                  : AppColors.muted.withOpacity(0.3),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Last 4 weeks',
                                style: theme.textTheme.bodySmall),
                            Row(
                              children: [
                                Text('Less ', style: theme.textTheme.bodySmall),
                                ...[0.1, 0.4, 0.7, 1.0].map((v) => Container(
                                      width: 12,
                                      height: 12,
                                      margin: const EdgeInsets.only(right: 3),
                                      decoration: BoxDecoration(
                                        color: AppColors.primaryBlue
                                            .withOpacity(v),
                                        borderRadius: BorderRadius.circular(3),
                                      ),
                                    )),
                                Text('More', style: theme.textTheme.bodySmall),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          AppColors.accentCoral.withOpacity(0.12),
                          AppColors.accentCoral.withOpacity(0.05),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: AppColors.accentCoral.withOpacity(0.2)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: AppColors.accentCoral.withOpacity(0.2),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.lightbulb_outline,
                              color: AppColors.accentCoral, size: 20),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('AI Insight',
                                style: theme.textTheme.titleMedium),
                            const SizedBox(height: 8),
                            Text(
                              'You tend to feel better on days when you focus on "$topTag". Keep tracking your activities to discover more patterns.',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                  color: AppColors.textSecondary, height: 1.5),
                            ),
                          ],
                        )),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final logs = ref.read(moodLogProvider);
                      if (logs.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('No data!')));
                        return;
                      }
                      final status = await Permission.storage.request();
                      if (!status.isGranted) return;
                      try {
                        String csv = 'Date,Mood,Intensity\n';
                        for (var log in logs) {
                          csv += '${log.date},${log.label},${log.intensity}\n';
                        }
                        final dir = await ExternalPath
                            .getExternalStoragePublicDirectory(
                                ExternalPath.DIRECTORY_DOWNLOAD);
                        final file = File(
                            '$dir/MentalHealth_Export_${DateTime.now().millisecondsSinceEpoch}.csv');
                        await file.writeAsString(csv);
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Saved to Downloads!')));
                          await SharePlus.instance.share(ShareParams(files: [XFile(file.path)]));
                        }
                      } catch (e) {
                        if (context.mounted)
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e')));
                      }
                    },
                    icon: const Icon(Icons.download_outlined),
                    label: const Text('Export My Data'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 52),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(100)),
                      side: BorderSide(color: AppColors.border),
                    ),
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: child,
    );
  }
}

class _MoodTipsCard extends StatelessWidget {
  final bool isTrendingUp;
  final bool isTrendingDown;
  const _MoodTipsCard(
      {required this.isTrendingUp, required this.isTrendingDown});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final bool isUp = isTrendingUp;
    final bool isDown = isTrendingDown;

    final Color accentColor = isUp
        ? const Color(0xFF34C97B)
        : isDown
            ? const Color(0xFFFF8C42)
            : const Color(0xFF5B9BD5);

    final IconData headerIcon = isUp
        ? Icons.trending_up_rounded
        : isDown
            ? Icons.trending_down_rounded
            : Icons.trending_flat_rounded;

    final String headerTitle = isUp
        ? '🎉 Your Mood is Rising!'
        : isDown
            ? '💙 Your Mood Needs a Boost'
            : '😊 Keep the Momentum Going';

    final String headerSubtitle = isUp
        ? 'Great progress this week — here\'s how to keep it up:'
        : isDown
            ? 'It\'s okay to have tough days. Try these to feel better:'
            : 'Your mood is steady — small steps keep you thriving:';

    final List<_TipItem> tips = isUp
        ? [
            _TipItem(
              icon: Icons.self_improvement_rounded,
              color: const Color(0xFF34C97B),
              title: 'Keep your routine strong',
              subtitle:
                  'Consistency is your superpower. Stick to the habits that are working.',
            ),
            _TipItem(
              icon: Icons.people_outline_rounded,
              color: const Color(0xFF5B9BD5),
              title: 'Share your wins',
              subtitle:
                  'Talk to someone you trust about what\'s going well — positivity is contagious.',
            ),
            _TipItem(
              icon: Icons.local_florist_outlined,
              color: const Color(0xFFA78BFA),
              title: 'Practice gratitude',
              subtitle:
                  'Write down 3 things you\'re grateful for today to amplify positive feelings.',
            ),
            _TipItem(
              icon: Icons.directions_run_rounded,
              color: const Color(0xFFFF8C42),
              title: 'Channel the energy',
              subtitle:
                  'Use your good mood to tackle something you\'ve been putting off.',
            ),
          ]
        : isDown
            ? [
                _TipItem(
                  icon: Icons.air_rounded,
                  color: const Color(0xFF5B9BD5),
                  title: 'Try a breathing exercise',
                  subtitle:
                      'Inhale for 4s, hold for 4s, exhale for 6s. Repeat 5 times to calm your nervous system.',
                ),
                _TipItem(
                  icon: Icons.directions_walk_rounded,
                  color: const Color(0xFF34C97B),
                  title: 'Get moving outdoors',
                  subtitle:
                      'Even a 10-minute walk in fresh air can noticeably lift your mood.',
                ),
                _TipItem(
                  icon: Icons.nightlight_round,
                  color: const Color(0xFFA78BFA),
                  title: 'Prioritise rest & sleep',
                  subtitle:
                      'A consistent sleep schedule is one of the most powerful mood regulators.',
                ),
                _TipItem(
                  icon: Icons.chat_bubble_outline_rounded,
                  color: const Color(0xFFFF8C42),
                  title: 'Talk it out',
                  subtitle:
                      'Consider journaling your feelings or chatting with the AI companion for support.',
                ),
              ]
            : [
                _TipItem(
                  icon: Icons.book_outlined,
                  color: const Color(0xFF5B9BD5),
                  title: 'Log consistently',
                  subtitle:
                      'Daily check-ins help you spot patterns and triggers before they escalate.',
                ),
                _TipItem(
                  icon: Icons.spa_outlined,
                  color: const Color(0xFF34C97B),
                  title: 'Add mindfulness moments',
                  subtitle:
                      'Even 5 minutes of mindfulness a day strengthens emotional resilience.',
                ),
                _TipItem(
                  icon: Icons.emoji_food_beverage_outlined,
                  color: const Color(0xFFFF8C42),
                  title: 'Stay hydrated',
                  subtitle:
                      'Dehydration subtly impacts mood — aim for 8 glasses of water daily.',
                ),
              ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accentColor.withOpacity(0.10),
            accentColor.withOpacity(0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentColor.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.18),
                  shape: BoxShape.circle,
                ),
                child: Icon(headerIcon, color: accentColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(headerTitle,
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: accentColor,
                        )),
                    const SizedBox(height: 2),
                    Text(headerSubtitle,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: AppColors.textSecondary,
                        )),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Tips list
          ...tips.map((tip) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: tip.color.withOpacity(0.14),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(tip.icon, color: tip.color, size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(tip.title,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              )),
                          const SizedBox(height: 2),
                          Text(tip.subtitle,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: AppColors.textSecondary,
                                height: 1.4,
                              )),
                        ],
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class _TipItem {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  const _TipItem({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });
}

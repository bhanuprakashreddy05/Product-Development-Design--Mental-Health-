import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/providers/user_provider.dart';
import '../../core/theme/app_theme.dart';


class MainShell extends ConsumerStatefulWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {


  static const _tabs = [
    _TabItem(icon: Icons.home_outlined, activeIcon: Icons.home, label: 'Home', path: '/app'),
    _TabItem(icon: Icons.edit_note, activeIcon: Icons.edit_note, label: 'Notes', path: '/app/journal'),
    _TabItem(icon: Icons.mic_none, activeIcon: Icons.mic, label: '', path: 'voice_trigger'), // Special placeholder
    _TabItem(icon: Icons.trending_up_outlined, activeIcon: Icons.trending_up, label: 'Progress', path: '/app/progress'),
    _TabItem(icon: Icons.person_outline, activeIcon: Icons.person, label: 'Profile', path: '/app/profile'),
  ];

  int _locationToIndex(String location) {
    if (location.startsWith('/app/journal')) return 1;
    if (location.startsWith('/app/progress')) return 3; // Shifted due to mic
    if (location.startsWith('/app/profile')) return 4;  // Shifted due to mic
    return 0;
  }



  @override
  void initState() {
    super.initState();
    // Start listening for "Hey Mid" wake word
    Future.microtask(() => ref.read(wakeWordProvider.notifier).startListening());
  }

  @override
  Widget build(BuildContext context) {
    // Listen for wake word trigger from any screen
    ref.listen(wakeWordProvider, (prev, next) {
      if (next == true) {
        _showQuickVoiceLog(context);
      }
    });

    final location = GoRouterState.of(context).uri.toString();

    final currentIndex = _locationToIndex(location);

    return Scaffold(
      extendBody: true,
      body: widget.child,
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
        height: 76,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface.withOpacity(0.94),
          borderRadius: BorderRadius.circular(32),
          border: Border.all(color: AppColors.border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(32),
          child: Row(
            children: _tabs.asMap().entries.map((entry) {
              final i = entry.key;
              final tab = entry.value;
              final isActive = i == currentIndex;

              if (tab.path == 'voice_trigger') {
                return Expanded(
                  child: Center(
                    child: GestureDetector(
                      onTap: () => _showQuickVoiceLog(context),
                      child: Container(
                        width: 54,
                        height: 54,
                        decoration: BoxDecoration(
                          color: AppColors.primaryBlue,
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primaryBlue.withOpacity(0.3),
                              blurRadius: 16,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(Icons.mic_rounded, color: Colors.white, size: 28),
                      ),
                    ),
                  ),
                );
              }

              return Expanded(
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => context.go(tab.path),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.primaryBlue.withOpacity(0.12) : Colors.transparent,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isActive ? tab.activeIcon : tab.icon,
                            color: isActive ? AppColors.primaryBlue : AppColors.textMuted,
                            size: 24,
                          ),
                        ),
                        const SizedBox(height: 4),
                        if (tab.label.isNotEmpty)
                          Text(
                            tab.label,
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                              color: isActive ? AppColors.primaryBlue : AppColors.textMuted,
                              letterSpacing: -0.2,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }

  void _showQuickVoiceLog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _QuickVoiceSheet(),
    );
  }
}

class _QuickVoiceSheet extends ConsumerStatefulWidget {
  const _QuickVoiceSheet();
  @override
  ConsumerState<_QuickVoiceSheet> createState() => _QuickVoiceSheetState();
}

class _QuickVoiceSheetState extends ConsumerState<_QuickVoiceSheet> with SingleTickerProviderStateMixin {
  final _stt = SpeechToText();
  bool _isListening = false;
  String _text = '';
  late AnimationController _ctrl;



  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true);
    _startRecording();
  }

  void _startRecording() async {
    final status = await Permission.microphone.request();
    if (status.isGranted) {
      final available = await _stt.initialize(
        onStatus: (s) {
          if (s == 'notListening' || s == 'done') {
            if (mounted) setState(() => _isListening = false);
          }
        },
        onError: (e) => debugPrint('STT Error: $e'),
      );
      if (available) {
        setState(() => _isListening = true);
        _stt.listen(
          onResult: (res) {
            if (mounted) setState(() => _text = res.recognizedWords);
          },
          listenFor: const Duration(seconds: 30),
          pauseFor: const Duration(seconds: 3),
          partialResults: true,
        );
      }
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Microphone permission denied')),
        );
        Navigator.pop(context);
      }
    }
  }

  void _save() async {
    if (_text.trim().isEmpty) { 
      Navigator.pop(context); 
      return; 
    }
    
    final entry = MoodEntry(
      date: DateTime.now(),
      emoji: '🎙️',
      label: 'Voice Note',
      intensity: 75,
      tags: ['Voice'],
      note: _text.trim(),
    );

    // Save to Mood Log
    await ref.read(moodLogProvider.notifier).add(entry);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Note saved to Journal! 📝'))
      );
      Navigator.pop(context);
    }
  }

  @override
  void dispose() { _ctrl.dispose(); _stt.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: EdgeInsets.fromLTRB(32, 24, 32, MediaQuery.of(context).viewInsets.bottom + 48),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(40)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 40,
            offset: const Offset(0, -10),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.borderDark,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 32),
          Text(_isListening ? 'Listening to your thoughts...' : 'Microphone paused', 
            style: theme.textTheme.titleMedium?.copyWith(color: AppColors.textSecondary)),
          const SizedBox(height: 36),
          ScaleTransition(
            scale: Tween<double>(begin: 1.0, end: 1.15).animate(
              CurvedAnimation(parent: _ctrl, curve: Curves.easeInOutSine)
            ),
            child: Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                color: AppColors.primaryBlue,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryBlue.withOpacity(0.3),
                    blurRadius: 32,
                    spreadRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.mic_rounded, color: Colors.white, size: 44)
            ),
          ),
          const SizedBox(height: 44),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.bgSoft,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: AppColors.border),
            ),
            child: Text(
              _text.isEmpty ? 'Waiting for your voice...' : _text,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyLarge?.copyWith(
                height: 1.6,
                color: _text.isEmpty ? AppColors.textMuted : AppColors.textPrimary,
                fontStyle: _text.isEmpty ? FontStyle.italic : FontStyle.normal,
              ),
            ),
          ),
          const SizedBox(height: 36),
          ElevatedButton(
            onPressed: _save,
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 58),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            ),
            child: const Text('Save Reflection', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

class _TabItem {

  final IconData icon;
  final IconData activeIcon;
  final String label;
  final String path;
  const _TabItem({
    required this.icon,
    required this.activeIcon,
    required this.label,
    required this.path,
  });
}

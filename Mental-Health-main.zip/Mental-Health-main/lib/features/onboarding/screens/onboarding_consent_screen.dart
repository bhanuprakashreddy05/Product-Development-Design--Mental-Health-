import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class OnboardingConsentScreen extends StatefulWidget {
  const OnboardingConsentScreen({super.key});

  @override
  State<OnboardingConsentScreen> createState() =>
      _OnboardingConsentScreenState();
}

class _OnboardingConsentScreenState extends State<OnboardingConsentScreen> {
  bool _dataSharing = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(32, 48, 32, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Shield icon
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: AppColors.primaryBlue.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.shield_outlined,
                          color: AppColors.primaryBlue, size: 32),
                    ),
                    const SizedBox(height: 24),
                    Text('Your Privacy Matters',
                        style: theme.textTheme.headlineLarge),
                    const SizedBox(height: 12),
                    Text(
                      "We're committed to keeping your mental health data safe and private.",
                      style: theme.textTheme.bodyLarge
                          ?.copyWith(color: AppColors.textSecondary),
                    ),
                    const SizedBox(height: 40),

                    // Privacy items
                    _PrivacyItem(
                      icon: Icons.lock_outline,
                      title: 'End-to-end Encryption',
                      description:
                          'Your conversations and journal entries are encrypted and only accessible to you.',
                    ),
                    const SizedBox(height: 24),
                    _PrivacyItem(
                      icon: Icons.visibility_off_outlined,
                      title: 'Anonymous by Default',
                      description:
                          "We don't share your personal information with third parties or advertisers.",
                    ),
                    const SizedBox(height: 24),
                    _PrivacyItem(
                      icon: Icons.health_and_safety_outlined,
                      title: 'HIPAA Compliant',
                      description:
                          'Our platform meets healthcare privacy standards to protect your data.',
                    ),
                    const SizedBox(height: 32),

                    // Data sharing toggle card
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.surface,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Help Improve Mental Health',
                                    style: theme.textTheme.titleMedium),
                                const SizedBox(height: 6),
                                Text(
                                  'Share anonymised usage data to help us improve the app. You can change this anytime.',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          Switch(
                            value: _dataSharing,
                            onChanged: (v) =>
                                setState(() => _dataSharing = v),
                            activeColor: AppColors.primaryBlue,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Terms text
                    Text.rich(
                      TextSpan(
                        text: 'By continuing, you agree to our ',
                        style: theme.textTheme.bodySmall,
                        children: [
                          TextSpan(
                            text: 'Terms of Service',
                            style: const TextStyle(
                                color: AppColors.primaryBlue,
                                decoration: TextDecoration.underline),
                          ),
                          const TextSpan(text: ' and '),
                          TextSpan(
                            text: 'Privacy Policy',
                            style: const TextStyle(
                                color: AppColors.primaryBlue,
                                decoration: TextDecoration.underline),
                          ),
                          const TextSpan(text: '.'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),

            // CTA
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 0, 32, 32),
              child: ElevatedButton(
                onPressed: () => context.go('/auth'),
                child: const Text('Get Started'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrivacyItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  const _PrivacyItem({
    required this.icon,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: AppColors.successMint.withOpacity(0.1),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Icon(icon, color: AppColors.successMint, size: 24),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: theme.textTheme.titleMedium),
              const SizedBox(height: 4),
              Text(description,
                  style: theme.textTheme.bodyMedium
                      ?.copyWith(color: AppColors.textSecondary, height: 1.5)),
            ],
          ),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_theme.dart';

class _Feature {
  final IconData icon;
  final String title;
  final String description;
  final List<Color> gradient;
  const _Feature({
    required this.icon,
    required this.title,
    required this.description,
    required this.gradient,
  });
}

const _features = [
  _Feature(
    icon: Icons.chat_bubble_outline,
    title: '24/7 AI Support',
    description:
        'Talk to your compassionate AI companion anytime, anywhere. Get CBT-based guidance in real-time.',
    gradient: [Color(0xFF5B7FFF), Color(0xFF8B9FFF)],
  ),
  _Feature(
    icon: Icons.trending_up,
    title: 'Track Your Journey',
    description:
        'Understand your patterns with mood tracking, insights, and personalised recommendations.',
    gradient: [Color(0xFFFF8C69), Color(0xFFFFB694)],
  ),
  _Feature(
    icon: Icons.menu_book_outlined,
    title: 'Guided Exercises',
    description:
        'Access breathing techniques, meditation, journaling prompts, and evidence-based CBT tools.',
    gradient: [Color(0xFF4CAF82), Color(0xFF6FD4A7)],
  ),
];

class OnboardingCarouselScreen extends StatefulWidget {
  const OnboardingCarouselScreen({super.key});

  @override
  State<OnboardingCarouselScreen> createState() =>
      _OnboardingCarouselScreenState();
}

class _OnboardingCarouselScreenState extends State<OnboardingCarouselScreen> {
  int _current = 0;

  void _next() {
    if (_current < _features.length - 1) {
      setState(() => _current++);
    } else {
      context.go('/consent');
    }
  }

  void _back() {
    if (_current > 0) {
      setState(() => _current--);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final feature = _features[_current];

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: PopScope(
        canPop: _current == 0,
        onPopInvokedWithResult: (didPop, result) {
          if (didPop) return;
          _back();
        },
        child: SafeArea(
          child: Column(
          children: [
            // Skip button
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: TextButton(
                  onPressed: () => context.go('/consent'),
                  child: Text('Skip',
                      style: TextStyle(color: AppColors.textSecondary)),
                ),
              ),
            ),

            // Feature content
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 400),
                child: _FeatureSlide(feature: feature, key: ValueKey(_current)),
              ),
            ),

            // Progress dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_features.length, (i) {
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 8,
                  width: i == _current ? 32 : 8,
                  decoration: BoxDecoration(
                    color: i == _current
                        ? AppColors.primaryBlue
                        : AppColors.muted,
                    borderRadius: BorderRadius.circular(100),
                  ),
                );
              }),
            ),
            const SizedBox(height: 32),

            // Next button
            Padding(
              padding: const EdgeInsets.fromLTRB(32, 0, 32, 32),
              child: ElevatedButton.icon(
                onPressed: _next,
                icon: const SizedBox.shrink(),
                label: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(_current < _features.length - 1
                        ? 'Next'
                        : 'Get Started'),
                    const SizedBox(width: 8),
                    const Icon(Icons.chevron_right, size: 20),
                  ],
                ),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 56),
                ),
              ),
            ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureSlide extends StatelessWidget {
  final _Feature feature;
  const _FeatureSlide({required this.feature, super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 128,
            height: 128,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: feature.gradient),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: feature.gradient.first.withOpacity(0.3),
                  blurRadius: 32,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Icon(feature.icon, color: Colors.white, size: 64),
          ),
          const SizedBox(height: 48),
          Text(
            feature.title,
            style: theme.textTheme.headlineLarge,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Text(
            feature.description,
            style: theme.textTheme.bodyLarge?.copyWith(
                color: AppColors.textSecondary, height: 1.6),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // Wellness Iris Palette - Calming & Premium
  static const primaryBlue = Color(0xFF5D3FD3); // Iris Purple
  static const primaryLight = Color(0xFFF3EFFF);
  static const accentCoral = Color(0xFFFFB7B2); // Peach Blossom
  static const accentMint = Color(0xFFB2E2F2); // Sky Blue
  
  // Backgrounds
  static const bgSoft = Color(0xFFFBF8FF);
  static const surfaceWhite = Color(0xFFFFFFFF);
  
  // Text
  static const textPrimary = Color(0xFF1E1B4B); // Deep Indigo
  static const textSecondary = Color(0xFF6366F1); // Muted Indigo
  static const textMuted = Color(0xFF94A3B8);
  
  // Status
  static const success = Color(0xFF34D399);
  static const warning = Color(0xFFFBBF24);
  static const error = Color(0xFFF12D2D);

  // Legacy Aliases (Fixing Lints)
  static const successMint = success;
  static const alertRed = error;
  static const muted = Color(0xFFE2E8F0);
  
  // Borders & Dividers
  static const border = Color(0x0D5D3FD3); // Faint Purple
  static const borderDark = Color(0xFFE2E8F0);

  // Dark mode - Mystical Night
  static const darkBg = Color(0xFF0F0C29);
  static const darkSurface = Color(0xFF1B1448);
  static const darkBorder = Color(0xFF2D2463);
  static const darkTextPrimary = Color(0xFFF8F0FF);
  static const darkTextSecondary = Color(0xFFA5B4FC);
}

class AppTheme {
  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.bgSoft,
      colorScheme: const ColorScheme.light(
        primary: AppColors.primaryBlue,
        secondary: AppColors.accentCoral,
        surface: AppColors.surfaceWhite,
        error: AppColors.error,
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: AppColors.textPrimary,
      ),
      textTheme: _buildTextTheme(AppColors.textPrimary),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryBlue,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          textStyle: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w600,
            fontSize: 15,
          ),
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surfaceWhite,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: AppColors.border),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceWhite,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
          borderSide: const BorderSide(color: AppColors.primaryBlue, width: 1.5),
        ),
        contentPadding: const EdgeInsets.all(20),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.surfaceWhite,
        selectedItemColor: AppColors.primaryBlue,
        unselectedItemColor: AppColors.textMuted,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.fraunces(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: AppColors.textPrimary,
        ),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
    );
  }

  static ThemeData get darkTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: AppColors.darkBg,
      colorScheme: const ColorScheme.dark(
        primary: AppColors.primaryBlue,
        secondary: AppColors.accentCoral,
        surface: AppColors.darkSurface,
        error: Colors.redAccent,
        onPrimary: Colors.white,
        onSurface: AppColors.darkTextPrimary,
      ),
      textTheme: _buildTextTheme(AppColors.darkTextPrimary),
      cardTheme: CardThemeData(
        color: AppColors.darkSurface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: const BorderSide(color: AppColors.darkBorder),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        titleTextStyle: GoogleFonts.fraunces(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: AppColors.darkTextPrimary,
        ),
        iconTheme: const IconThemeData(color: AppColors.darkTextPrimary),
      ),
    );
  }

  static TextTheme _buildTextTheme(Color color) {
    return TextTheme(
      displayLarge: GoogleFonts.fraunces(fontSize: 34, fontWeight: FontWeight.w700, color: color),
      displayMedium: GoogleFonts.fraunces(fontSize: 30, fontWeight: FontWeight.w700, color: color),
      headlineLarge: GoogleFonts.fraunces(fontSize: 26, fontWeight: FontWeight.w700, color: color),
      headlineMedium: GoogleFonts.fraunces(fontSize: 22, fontWeight: FontWeight.w700, color: color),
      headlineSmall: GoogleFonts.fraunces(fontSize: 18, fontWeight: FontWeight.w700, color: color),
      titleLarge: GoogleFonts.plusJakartaSans(fontSize: 18, fontWeight: FontWeight.w700, color: color),
      titleMedium: GoogleFonts.plusJakartaSans(fontSize: 16, fontWeight: FontWeight.w600, color: color),
      bodyLarge: GoogleFonts.plusJakartaSans(fontSize: 16, fontWeight: FontWeight.w400, color: color),
      bodyMedium: GoogleFonts.plusJakartaSans(fontSize: 14, fontWeight: FontWeight.w400, color: color),
      bodySmall: GoogleFonts.plusJakartaSans(fontSize: 12, fontWeight: FontWeight.w400, color: color.withOpacity(0.6)),
    );
  }
}


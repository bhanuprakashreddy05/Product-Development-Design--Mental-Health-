import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;

/// Lightweight Gemini streaming client.
///
/// Uses the `GEMINI_API_KEY` value from the loaded `.env` file (main.dart
/// already loads `.env`). Exposes a streaming API (`streamGenerateContent`)
/// which yields incremental text deltas parsed from the SSE response.
class GeminiService {
  final String model;

  GeminiService({this.model = 'gemini-1.5-flash-latest'});

  /// Streams incremental text deltas from Gemini's SSE streaming endpoint.
  ///
  /// Throws if `GEMINI_API_KEY` is not set in the environment.
  Stream<String> streamGenerateContent({
    required String systemPrompt,
    required List<Map<String, dynamic>> contents,
    Map<String, dynamic>? generationConfig,
    Duration timeout = const Duration(seconds: 60),
  }) async* {
    final apiKey = dotenv.env['GEMINI_API_KEY'] ?? '';
    if (apiKey.isEmpty || apiKey == 'YOUR_GEMINI_API_KEY_HERE') {
      throw Exception('Gemini API key not set in .env (GEMINI_API_KEY).');
    }

    final url = Uri.parse(
      'https://generativelanguage.googleapis.com/v1beta/models/'
      '$model:streamGenerateContent?alt=sse&key=$apiKey',
    );

    final body = {
      'system_instruction': {
        'parts': [
          {'text': systemPrompt}
        ]
      },
      'contents': contents,
      'generationConfig': generationConfig ??
          {
            'temperature': 0.78,
            'maxOutputTokens': 400,
            'topP': 0.9,
          },
    };

    final request = http.Request('POST', url)
      ..headers['Content-Type'] = 'application/json'
      ..body = jsonEncode(body);

    final streamedResponse = await request.send().timeout(timeout);

    if (streamedResponse.statusCode != 200) {
      final errBody = await streamedResponse.stream.bytesToString();
      String errMsg = errBody;
      try {
        final errJson = jsonDecode(errBody);
        errMsg = errJson['error']?['message'] ?? errBody;
      } catch (_) {}
      throw Exception(
          'Gemini API error (${streamedResponse.statusCode}): $errMsg');
    }

    // Parse SSE stream line-by-line. Each data line starts with `data: `.
    final utf8Stream = streamedResponse.stream
        .transform(utf8.decoder)
        .transform(const LineSplitter());

    await for (final chunk in utf8Stream) {
      if (!chunk.startsWith('data: ')) continue;
      final jsonStr = chunk.substring(6).trim();
      if (jsonStr == '[DONE]' || jsonStr.isEmpty) continue;

      try {
        final data = jsonDecode(jsonStr);
        final delta = data['candidates']?[0]['content']?['parts']?[0]['text']
                as String? ??
            '';
        if (delta.isNotEmpty) yield delta;
      } catch (e) {
        // Log error but don't crash the stream
        debugPrint('Gemini Stream Parse Error: $e | Raw: $jsonStr');
      }
    }
  }

  /// Convenience method that collects the full response from the stream.
  Future<String> generateComplete({
    required String systemPrompt,
    required List<Map<String, dynamic>> contents,
    Map<String, dynamic>? generationConfig,
  }) async {
    final buf = StringBuffer();
    await for (final delta in streamGenerateContent(
      systemPrompt: systemPrompt,
      contents: contents,
      generationConfig: generationConfig,
    )) {
      buf.write(delta);
    }
    return buf.toString();
  }
}

final geminiService = GeminiService();

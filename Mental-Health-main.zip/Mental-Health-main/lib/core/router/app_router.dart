import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../features/onboarding/screens/splash_screen.dart';
import '../../features/onboarding/screens/onboarding_carousel_screen.dart';
import '../../features/onboarding/screens/onboarding_consent_screen.dart';
import '../../features/auth/screens/auth_screen.dart';
import '../../features/assessment/screens/assessment_screen.dart';
import '../../features/shell/main_shell.dart';
import '../../features/home/screens/home_screen.dart';
import '../../features/chat/screens/chat_screen.dart';
import '../../features/mood/screens/mood_log_screen.dart';
import '../../features/exercises/screens/exercises_screen.dart';
import '../../features/exercises/screens/exercise_detail_screen.dart';
import '../../features/journal/screens/journal_screen.dart';
import '../../features/progress/screens/progress_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/crisis/screens/crisis_screen.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>();
final _shellNavigatorKey = GlobalKey<NavigatorState>();

final router = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/',
  routes: [
    // ─── Onboarding / Auth flow (no bottom nav) ───────────────────────────
    GoRoute(
      path: '/',
      builder: (context, state) => const SplashScreen(),
    ),
    GoRoute(
      path: '/onboarding',
      builder: (context, state) => const OnboardingCarouselScreen(),
    ),
    GoRoute(
      path: '/consent',
      builder: (context, state) => const OnboardingConsentScreen(),
    ),
    GoRoute(
      path: '/auth',
      builder: (context, state) => const AuthScreen(),
    ),
    GoRoute(
      path: '/assessment',
      builder: (context, state) => const AssessmentScreen(),
    ),
    GoRoute(
      path: '/crisis',
      builder: (context, state) => const CrisisScreen(),
    ),

    // ─── Main app shell (with bottom nav) ────────────────────────────────
    ShellRoute(
      navigatorKey: _shellNavigatorKey,
      builder: (context, state, child) => MainShell(child: child),
      routes: [
        GoRoute(
          path: '/app',
          builder: (context, state) => const HomeScreen(),
        ),
        GoRoute(
          path: '/app/chat',
          builder: (context, state) => const ChatScreen(),
        ),
        GoRoute(
          path: '/app/mood',
          builder: (context, state) => const MoodLogScreen(),
        ),
        GoRoute(
          path: '/app/exercises',
          builder: (context, state) => const ExercisesScreen(),
        ),
        GoRoute(
          path: '/app/exercises/:id',
          builder: (context, state) => ExerciseDetailScreen(
            exerciseId: state.pathParameters['id']!,
          ),
        ),
        GoRoute(
          path: '/app/journal',
          builder: (context, state) => const JournalScreen(),
        ),
        GoRoute(
          path: '/app/progress',
          builder: (context, state) => const ProgressScreen(),
        ),
        GoRoute(
          path: '/app/profile',
          builder: (context, state) => const ProfileScreen(),
        ),
      ],
    ),
  ],
);

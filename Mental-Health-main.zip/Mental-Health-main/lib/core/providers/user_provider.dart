import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart';


// ─── Auth ────────────────────────────────────────────────────────────────────

final authStateProvider = StreamProvider<User?>((ref) {
  return FirebaseAuth.instance.authStateChanges();
});

final userDisplayNameProvider = Provider<String>((ref) {
  final user = ref.watch(authStateProvider).value;
  return user?.displayName ?? 'User';
});

class UserProfileNotifier extends AutoDisposeAsyncNotifier<void> {
  @override
  Future<void> build() async {}

  Future<void> updateDisplayName(String name) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.updateDisplayName(name);
        // Refresh auth state
        ref.invalidate(authStateProvider);
      }
    });
  }

  Future<void> updatePassword(String newPassword) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        await user.updatePassword(newPassword);
      }
    });
  }

  Future<void> updateProfileImage() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.gallery);
      
      if (image != null) {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          // Since we don't have Firebase Storage enabled, we'll store the local path in user state
          // and use it. In a real app, you'd upload to Storage first.
          await user.updatePhotoURL(image.path);
          ref.invalidate(authStateProvider);
        }
      }
    });
  }
}

final userProfileProvider =
    AutoDisposeAsyncNotifierProvider<UserProfileNotifier, void>(
        UserProfileNotifier.new);


// ─── Theme mode ──────────────────────────────────────────────────────────────

class ThemeModeNotifier extends AsyncNotifier<ThemeMode> {
  @override
  Future<ThemeMode> build() async {
    final prefs = await SharedPreferences.getInstance();
    final isDark = prefs.getBool('dark_mode') ?? false;
    return isDark ? ThemeMode.dark : ThemeMode.light;
  }

  Future<void> setDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', value);
    state = AsyncData(value ? ThemeMode.dark : ThemeMode.light);
  }

  bool get isDark => state.value == ThemeMode.dark;
}


final themeModeProvider =
    AsyncNotifierProvider<ThemeModeNotifier, ThemeMode>(ThemeModeNotifier.new);

// ─── Settings (notifications, wearable) ──────────────────────────────────────

class SettingsNotifier extends AsyncNotifier<Map<String, bool>> {
  static const _notifKey = 'notifications_enabled';
  static const _wearableKey = 'wearable_connected';

  @override
  Future<Map<String, bool>> build() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'notifications': prefs.getBool(_notifKey) ?? true,
      'wearable': prefs.getBool(_wearableKey) ?? false,
    };
  }

  Future<void> setNotifications(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_notifKey, value);
    state = AsyncData({...state.value ?? {}, 'notifications': value});
    
    // Persistent notification handling
    if (value) {
      await NotificationService.showPersistentNotification();
    } else {
      await NotificationService.cancelPersistentNotification();
    }
  }

  Future<void> setWearable(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_wearableKey, value);
    state = AsyncData({...state.value ?? {}, 'wearable': value});
  }
}

// ── Notification Service ───────────────────────────────────────────────────

class NotificationService {
  static final _notifications = FlutterLocalNotificationsPlugin();
  static const int _persistentId = 888;

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    await _notifications.initialize(
      const InitializationSettings(android: android, iOS: ios),
    );
  }

  static Future<void> showPersistentNotification() async {
    const androidDetails = AndroidNotificationDetails(
      'persistent_channel',
      'Mental Health Active',
      channelDescription: 'Keeps Mental Health accessible in notification panel',
      importance: Importance.low,
      priority: Priority.low,
      ongoing: true,
      autoCancel: false,
      showWhen: false,
      icon: '@mipmap/ic_launcher',
    );
    
    const notificationDetails = NotificationDetails(android: androidDetails);
    
    await _notifications.show(
      _persistentId,
      'Mental Health is active',
      'Track your well-being',
      notificationDetails,
    );
  }

  static Future<void> cancelPersistentNotification() async {
    await _notifications.cancel(_persistentId);
  }
}

final settingsProvider =
    AsyncNotifierProvider<SettingsNotifier, Map<String, bool>>(
        SettingsNotifier.new);


// ─── Streak ───────────────────────────────────────────────────────────────────

class StreakNotifier extends Notifier<int> {
  @override
  int build() {
    final user = ref.watch(authStateProvider).value;
    if (user != null) {
      _loadStreak(user.uid);
    }
    return 0;
  }

  Future<void> _loadStreak(String uid) async {
    final snapshot = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    if (snapshot.exists) {
      state = snapshot.data()?['streak'] ?? 0;
    } else {
      state = 0;
    }
  }

  Future<void> updateStreak() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final docRef = FirebaseFirestore.instance.collection('users').doc(uid);
    final snapshot = await docRef.get();
    
    final lastCheckInStr = snapshot.data()?['last_check_in'] as String?;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    if (lastCheckInStr != null) {
      final lastCheckIn = DateTime.parse(lastCheckInStr);
      final difference = today.difference(lastCheckIn).inDays;

      if (difference == 1) {
        int currentStreak = snapshot.data()?['streak'] ?? 0;
        currentStreak++;
        await docRef.set({'streak': currentStreak, 'last_check_in': today.toIso8601String()}, SetOptions(merge: true));
        state = currentStreak;
      } else if (difference > 1) {
        await docRef.set({'streak': 1, 'last_check_in': today.toIso8601String()}, SetOptions(merge: true));
        state = 1;
      } else if (difference == 0) {
        state = snapshot.data()?['streak'] ?? 1;
      }
    } else {
      await docRef.set({'streak': 1, 'last_check_in': today.toIso8601String()}, SetOptions(merge: true));
      state = 1;
    }
  }
}

final streakProvider =
    NotifierProvider<StreakNotifier, int>(() => StreakNotifier());

// ─── Mood Logs ────────────────────────────────────────────────────────────────

/// One mood entry persisted to SharedPreferences.
class MoodEntry {
  final String? id;
  final DateTime date;
  final String emoji;
  final String label;
  final int intensity; // 0-100
  final List<String> tags;
  final String note;

  const MoodEntry({
    this.id,
    required this.date,
    required this.emoji,
    required this.label,
    required this.intensity,
    required this.tags,
    required this.note,
  });

  Map<String, dynamic> toJson() => {
        'date': date.toIso8601String(),
        'emoji': emoji,
        'label': label,
        'intensity': intensity,
        'tags': tags,
        'note': note,
      };

  factory MoodEntry.fromJson(Map<String, dynamic> j, {String? id}) => MoodEntry(
        id: id,
        date: DateTime.parse(j['date'] as String),
        emoji: j['emoji'] as String,
        label: j['label'] as String,
        intensity: j['intensity'] as int,
        tags: List<String>.from(j['tags'] as List),
        note: j['note'] as String,
      );
}

class MoodLogNotifier extends Notifier<List<MoodEntry>> {
  @override
  List<MoodEntry> build() {
    final user = ref.watch(authStateProvider).value;
    if (user != null) {
      _load(user.uid);
    }
    return [];
  }

  Future<void> _load(String uid) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('mood_logs')
        .get();

    final logs = snapshot.docs.map((doc) {
      return MoodEntry.fromJson(doc.data(), id: doc.id);
    }).toList()
      ..sort((a, b) => b.date.compareTo(a.date));

    state = logs;
  }

  Future<void> add(MoodEntry entry) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final docRef = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('mood_logs')
        .add(entry.toJson());

    // Create a new entry with the generated ID
    final entryWithId = MoodEntry(
      id: docRef.id,
      date: entry.date,
      emoji: entry.emoji,
      label: entry.label,
      intensity: entry.intensity,
      tags: entry.tags,
      note: entry.note,
    );

    final updated = [entryWithId, ...state];
    updated.sort((a, b) => b.date.compareTo(a.date));
    state = updated;
  }

  Future<void> delete(String id) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('mood_logs')
        .doc(id)
        .delete();

    state = state.where((entry) => entry.id != id).toList();
  }

  Future<void> clearData() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final batch = FirebaseFirestore.instance.batch();
    final snapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('mood_logs')
        .get();

    for (var doc in snapshot.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();
    state = [];
  }

  Future<void> reload() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid != null) {
      await _load(uid);
    }
  }

  /// Returns the last 7 mood-log intensities grouped by day (Mon-Sun of current week).
  /// Index 0 = Monday, 6 = Sunday. Returns null for days with no logs.
  List<double?> weeklyIntensities() {
    final now = DateTime.now();
    final weekStart =
        DateTime(now.year, now.month, now.day - (now.weekday - 1));
    final result = List<double?>.filled(7, null);
    for (int d = 0; d < 7; d++) {
      final day = weekStart.add(Duration(days: d));
      final entries = state.where((e) =>
          e.date.year == day.year &&
          e.date.month == day.month &&
          e.date.day == day.day);
      if (entries.isNotEmpty) {
        result[d] =
            entries.map((e) => e.intensity.toDouble()).reduce((a, b) => a + b) /
                entries.length;
      }
    }
    return result;
  }

  /// Returns a 28-element list (4 weeks × 7 days) for the heatmap.
  /// Each value is 0 (no entry) or 1 (has entry).
  List<int> heatmap28() {
    final now = DateTime.now();
    final result = <int>[];
    for (int i = 27; i >= 0; i--) {
      final day = DateTime(now.year, now.month, now.day - i);
      final hasEntry = state.any((e) =>
          e.date.year == day.year &&
          e.date.month == day.month &&
          e.date.day == day.day);
      result.add(hasEntry ? 1 : 0);
    }
    return result;
  }

  /// Weekly summary stats.
  Map<String, int> weeklySummary() {
    final now = DateTime.now();
    final weekStart =
        DateTime(now.year, now.month, now.day - (now.weekday - 1));
    final thisWeek = state.where((e) => e.date.isAfter(
        weekStart.subtract(const Duration(seconds: 1))));
    return {
      'checkIns': thisWeek.length,
      'journalEntries': 0, // extended in journal feature
    };
  }

  /// Average intensity this week (0-100), or null if no logs.
  double? weeklyAverage() {
    final now = DateTime.now();
    final weekStart =
        DateTime(now.year, now.month, now.day - (now.weekday - 1));
    final entries = state
        .where((e) =>
            e.date.isAfter(weekStart.subtract(const Duration(seconds: 1))))
        .toList();
    if (entries.isEmpty) return null;
    return entries.map((e) => e.intensity).reduce((a, b) => a + b) /
        entries.length;
  }

  /// Most common tag this week, or null.
  String? topTag() {
    final now = DateTime.now();
    final weekStart =
        DateTime(now.year, now.month, now.day - (now.weekday - 1));
    final tags = state
        .where((e) =>
            e.date.isAfter(weekStart.subtract(const Duration(seconds: 1))))
        .expand((e) => e.tags)
        .toList();
    if (tags.isEmpty) return null;
    final freq = <String, int>{};
    for (final t in tags) {
      freq[t] = (freq[t] ?? 0) + 1;
    }
    return freq.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
  }

  /// Average intensity today (0-100), or null if no logs.
  double? todayAverage() {
    final now = DateTime.now();
    final entries = state
        .where((e) =>
            e.date.year == now.year &&
            e.date.month == now.month &&
            e.date.day == now.day)
        .toList();
    if (entries.isEmpty) return null;
    return entries.map((e) => e.intensity).reduce((a, b) => a + b) /
        entries.length;
  }
}

final moodLogProvider =
    NotifierProvider<MoodLogNotifier, List<MoodEntry>>(() => MoodLogNotifier());

// ── Wake Word ──────────────────────────────────────────────────────────────

class WakeWordNotifier extends StateNotifier<bool> {
  WakeWordNotifier() : super(false);
  final SpeechToText _stt = SpeechToText();

  Future<void> startListening() async {
    final available = await _stt.initialize();
    if (available) {
      _listen();
    }
  }

  void _listen() {
    _stt.listen(
      onResult: (res) {
        final words = res.recognizedWords.toLowerCase();
        if (words.contains('hey mid') || 
            words.contains('hay mid') || 
            words.contains('hi mind') || 
            words.contains('hey mind')) {
          
          if (!state) { // Prevent double trigger
            state = true;
            // Reset after trigger 
            Future.delayed(const Duration(seconds: 1), () => state = false);
          }
        }
      },
      listenFor: const Duration(minutes: 5),
      pauseFor: const Duration(seconds: 20),
      onDevice: true,
      cancelOnError: false,
      listenMode: ListenMode.confirmation,
    );
    
    // Auto-restart if it stops naturally
    Future.delayed(const Duration(minutes: 5), () {
      if (!state) _listen();
    });

  }

  Future<void> stop() async {
    await _stt.stop();
  }
}

final wakeWordProvider = StateNotifierProvider<WakeWordNotifier, bool>((ref) {
  return WakeWordNotifier();
});

